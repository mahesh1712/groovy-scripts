#!/bin/bash
echo "passing file to integration AMI creation"