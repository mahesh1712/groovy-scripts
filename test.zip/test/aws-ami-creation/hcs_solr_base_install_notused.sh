
=============================================================================================
Below scripts are not used now as we are testing Java AMI approach.
ami id: ami-062ef0a430a682df6
ami name: Deere_Java-amzn-ami-hvm-2017.09.1.20180307-x86_64-gp2-2018.05.07)
=============================================================================================


#########################
# Hybris Solr (HCS Solr) base install used for AMI creation.
#########################

groupadd hcssolrgroup
useradd -g hcssolrgroup hcssolruser
# To see group membership ===> lid -g hcssolrgroup

# Perform OS update
yum update -y
aws --region us-east-1 s3 cp s3://aws-parts-ecommerce-devl-hcs/solr_oob.zip /tmp/ --sse AES256
unzip /tmp/solr_oob.zip -d /tmp/


#mkdir -p /www/solrCore
#mv /tmp/solr /www/solrCore/

mv /tmp/solr /www/

chown -R hcssolruser:hcssolrgroup /www/
chmod 740 /www
#chmod 740 /www/solrCore

cd /www/solr/bin/
chmod +x /www/solr/bin/solr


echo "The hcs_solr_base_install.sh script has now completed."
