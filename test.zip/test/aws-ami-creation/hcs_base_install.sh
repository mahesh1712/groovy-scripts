#########################
# Hybris (HCS) base install used for AMI creation.
#########################

groupadd hcsgroup
useradd -g hcsgroup hcsuser
# To see group membership ===> lid -g hcsgroup

# Perform OS update
yum update -y

mkdir -p /www/hybrisCore
chown hcsuser:hcsgroup /www
chown hcsuser:hcsgroup /www/hybrisCore
chmod 740 /www
chmod 740 /www/hybrisCore

yum -y install git gcc gcc-c++ autoconf automake
yum -y install libpng-devel libjpeg-devel libtiff-devel
ldconfig /usr/local/lib

cd /tmp
git clone https://github.com/ImageMagick/ImageMagick.git
cd /tmp/ImageMagick
git checkout tags/7.0.7-35

./configure
make clean
make install

########################
# To validate the install of Imagemagick do the following:
# $ aws --region us-east-1 s3 cp s3://aws-parts-ecommerce-devl-hcs/error.png /tmp
# $ /usr/local/bin/magick /tmp/error.png -resize 500X500 /tmp/output.png
# To verify ImageMagick can handle all needed image formats:
# $ /usr/local/bin/convert -list configure
# Output should include: DELEGATES:  mpeg jng jpeg png ps tiff zlib
# 06JUN2018 IM Session above delegates confirmed by Cyndi Sadler.
########################

aws --region us-east-1 s3 cp s3://aws-parts-ecommerce-devl-hcs/truetypefonts.zip /tmp/truetypefonts/ --sse AES256
unzip /tmp/truetypefonts/truetypefonts.zip -d /tmp/truetypefonts/
mkdir /usr/share/fonts/msttcore/
mv /tmp/truetypefonts/*.* /usr/share/fonts/msttcore/
rm -rf /tmp/truetypefonts/
cd /usr/share/fonts/msttcore/
mkfontscale
mkfontdir
fc-cache

########################
# To validate the install of the truetypefonts do the following:
# fc-list {enter}
# The list of fonts should include “Arial,Arial Black:style=Black,Normal…”
########################


echo "The hcs_base_install.sh script has now completed."






###### INFO BELOW SHOULD NOT BE RUN, BUT KEEPING FOR ARCHIVE REFERENCE #######
# Potential libraries that could be needed in the future for ImageMagick
#yum -y install libfftw3.so*
#yum -y install libwmflite*
#yum -y install libgs.so*
#yum -y install libltdl.so*
#yum -y install libpango-1.0.so*
#yum -y install ghostscript
#yum -y install libICE
#yum -y install libSM
#yum -y install libXext
#yum -y install cairo
#yum -y install fftw3
