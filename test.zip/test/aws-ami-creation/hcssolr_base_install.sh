#########################
# Hybris solr base install used for AMI creation.
#########################

groupadd hcssolrgroup
useradd -g hcssolrgroup hcssolruser

# Perform OS update
#yum update -y
#Perform dos2unix install
yum install -y dos2unix

mkdir -p /www
chown -R hcssolruser:hcssolrgroup /www
chmod -R 740 /www

# Install awslogs
sudo yum install -y awslogs

echo "The hcssolr_base_install.sh script has now completed."
