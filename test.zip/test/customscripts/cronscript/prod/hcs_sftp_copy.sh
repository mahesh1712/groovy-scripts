#!/bin/bash
if [ ! -d "/tmp/jdstoredeltaxml" ] 
then
    mkdir /tmp/jdstoredeltaxml
fi
ARTIFACTORY_PASSWORD=$(aws ssm get-parameter --region us-east-1 --name hcssalesforcesftppasswordprod --with-decryption | grep Value | awk -F '"' '{print $4}')
sshpass -p "$ARTIFACTORY_PASSWORD" sftp -o StrictHostKeyChecking=no 7315370@ftp.s7.exacttarget.com:/Import/jdstore/delta/prod/* /tmp/jdstoredeltaxml/
aws s3 cp "/tmp/jdstoredeltaxml/" "s3://aws-parts-ecommerce-prod-hybrislogs/jdstoredeltaxml/ProductDelta/" --recursive --region us-east-1 --exclude "*" --include "ProductDelta*" --sse AES256
aws s3 cp "/tmp/jdstoredeltaxml/" "s3://aws-parts-ecommerce-prod-hybrislogs/jdstoredeltaxml/OrderDelta/" --recursive --region us-east-1 --exclude "*" --include "OrderDelta*" --sse AES256