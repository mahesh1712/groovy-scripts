#!/bin/bash
if [ ! -d "/tmp/jdstoredeltaxml" ] 
then
    mkdir /tmp/jdstoredeltaxml
fi
ARTIFACTORY_PASSWORD=$(aws ssm get-parameter --region us-east-1 --name hcssalesforcesftppasswordcert2 --with-decryption | grep Value | awk -F '"' '{print $4}')
sshpass -p "8fsh92upNim@" sftp -o StrictHostKeyChecking=no 7315370@ftp.s7.exacttarget.com:/Import/jdstore/delta/test/* /tmp/jdstoredeltaxml/
aws --region us-east-1 s3 cp /tmp/jdstoredeltaxml/* s3://aws-parts-ecommerce-cert2-hybrislogs/jdstoredeltaxml/ --sse AES256