#29NOV2016 TD21116
#=================================

echo
echo "** STARTING heap_check.sh shell script. ***"
echo "PID being checked: ["$1"]."

if [[ "$1" == '' ]]; then

   echo "ERROR: Aborting test due to no PID found."
   echo
   echo "USAGE:"
   echo "PARM-1 = PID of application to be checked for HEAP size."
   echo "PARM-2 = Threshold of %OLD-HEAP-USED at which an alert email is sent."
   echo "PARM-3 = Email address to whom this script will send the alert notification."
   echo "PARM-4 = Environment"
   echo "Example: /www/jvm-heap-usage.sh 61370 13000 someone@somewhere.com CERT"

else

   echo "STEP#1: Get garbage collection values to determine the overall heap used (for information only)."
   echo "        Also get the 'OU' value for later determination of %OLD-HEAP-USED, which drives the alert logic."
   echo "jstat -gc $1"
   jstat -gc $1 > /www/utilities/heap_check/temp/jstat_gc_output.txt
   cat /www/utilities/heap_check/temp/jstat_gc_output.txt
   echo
   cat /www/utilities/heap_check/temp/jstat_gc_output.txt | tail -n 1 | awk '{ print $3 }' > /www/utilities/heap_check/temp/s0u_col3.txt
   cat /www/utilities/heap_check/temp/jstat_gc_output.txt | tail -n 1 | awk '{ print $4 }' > /www/utilities/heap_check/temp/s1u_col4.txt
   cat /www/utilities/heap_check/temp/jstat_gc_output.txt | tail -n 1 | awk '{ print $6 }' > /www/utilities/heap_check/temp/eu_col6.txt
   #Get the "OU" value, which is the "current usage of old area in KB"
   cat /www/utilities/heap_check/temp/jstat_gc_output.txt | tail -n 1 | awk '{ print $8 }' > /www/utilities/heap_check/temp/ou_col8.txt
   cat /www/utilities/heap_check/temp/jstat_gc_output.txt | tail -n 1 | awk '{ print $10 }' > /www/utilities/heap_check/temp/mu_col10.txt

   s0u_col3_str=$(</www/utilities/heap_check/temp/s0u_col3.txt)
   s1u_col4_str=$(</www/utilities/heap_check/temp/s1u_col4.txt)
   eu_col6_str=$(</www/utilities/heap_check/temp/eu_col6.txt)
   ou_col8_str=$(</www/utilities/heap_check/temp/ou_col8.txt)
   mu_col10_str=$(</www/utilities/heap_check/temp/mu_col10.txt)

   s0u_col3_num=${s0u_col3_str%.*}
   s1u_col4_num=${s1u_col4_str%.*}
   eu_col6_num=${eu_col6_str%.*}
   ou_col8_num=${ou_col8_str%.*}
   mu_col10_num=${mu_col10_str%.*}

   echo "s0u_col3_num="$s0u_col3_num
   echo "s1u_col4_num="$s1u_col4_num
   echo "eu_col6_num="$eu_col6_num
   echo "ou_col8_num="$ou_col8_num
   echo "mu_col10_num="$mu_col10_num

   total=$(( s0u_col3_num + s1u_col4_num + eu_col6_num + ou_col8_num + mu_col10_num ))
   echo "Total is ["$total"] kilobytes, which when divided by 1024 is..."
   echo
   mem_used_val=$(( total/1024 ))
   echo "Heap used in megabytes: "$mem_used_val
   echo

   echo "STEP#2: Determine the %OLD-HEAP-USED, by relating the 'OU' (obtained earlier) with the 'OGCMX' being obtained now."
   echo "jstat -gccapacity $1"
   jstat -gccapacity $1 > /www/utilities/heap_check/temp/jstat_gccapacity_output.txt
   cat /www/utilities/heap_check/temp/jstat_gccapacity_output.txt

   #Get the "OGCMX" value, which is the "maximum size of old area in KB"
   cat /www/utilities/heap_check/temp/jstat_gccapacity_output.txt | tail -n 1 | awk '{ print $8 }' > /www/utilities/heap_check/temp/ogcmx_col8.txt

   ou_col8_str=$(</www/utilities/heap_check/temp/ou_col8.txt)
   ogcmx_str=$(</www/utilities/heap_check/temp/ogcmx_col8.txt)

   #echo "ou_col8_str="$ou_col8_str
   #echo "ogcmx_str="$ogcmx_str

   #Convert to numbers:
   ou_val=${ou_col8_str%.*}
   ou_val=$(( ou_val/1024 ))
   ogcmx_val=${ogcmx_str%.*}
   ogcmx_val=$(( ogcmx_val/1024 ))

   echo
   echo "The following ou_val comes from jstat -gc [col#8], while the ogcmx_val comes from jstat -gccapacity [col#8]."
   echo "ou_val="$ou_val
   echo "ogcmx_val="$ogcmx_val

   heap_old_area_percentage_raw=$(bc <<<"scale=2; $ou_val/$ogcmx_val" | bc)
   #echo "heap_old_area_percentage_raw="$heap_old_area_percentage_raw

   #heap_old_area_percentage_used=$((  heap_old_area_percentage_raw*100  ))
   heap_old_area_percentage_used="$(echo "$heap_old_area_percentage_raw*100" | bc)"
   echo "heap_old_area_percentage_used="$heap_old_area_percentage_used

   printf -v heap_old_area_percentage_used %.0f "$heap_old_area_percentage_used"
   heap_old_area_percentage_used_threshold=$2
   echo
   echo "*** RESULTS *************************************************************"
   echo "%OLD-HEAP-USED: "$heap_old_area_percentage_used"%"
   echo "%OLD-HEAP-LIMIT: "$heap_old_area_percentage_used_threshold"%"

   if (("$heap_old_area_percentage_used_threshold" == "101")); then
      echo "Sending email for health check report (sent when user selects threshold of 101)..."
      echo "$4: report on heap (USED:$heap_old_area_percentage_used%) for server $HOSTNAME at $(date)" | aws sns publish --region us-east-1 --topic-arn arn:aws:sns:us-east-1:122749220977:hcsheap-cert1 --message "$4: Hybris heap health check report ($heap_old_area_percentage_used %) for server $HOSTNAME $3"
   elif (("$heap_old_area_percentage_used" > $heap_old_area_percentage_used_threshold)); then
      echo "EXCEEDED LIMIT: sending email..."
      echo "$4: RUNNING LOW ON HEAP (USED:$heap_old_area_percentage_used%; ALERT AT:$heap_old_area_percentage_used_threshold %) for server $HOSTNAME at $(date)" | aws sns publish --region us-east-1 --topic-arn arn:aws:sns:us-east-1:122749220977:hcsheap-cert1 --message "$4: Hybris heap health check report ($heap_old_area_percentage_used %) for server $HOSTNAME $3"
   else
      echo "WITHIN LIMIT."
   fi
   echo "************************************************************************"

fi
