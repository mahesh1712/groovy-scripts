#!/bin/bash

if [[ "$1" == "createtypesystem" ]]; then
	aws s3 --region us-east-1 rm s3://aws-parts-ecommerce-devl-hcs/typesystem/createtypesystem.txt
	truststore_changeme="rdstruststore.password=<CHANGE_ME>"
	pwd_changeme="db.password=<CHANGE_ME>"
	hcsdbpassword=$(aws ssm get-parameter --region us-east-1 --name hcsdbpassword --with-decryption | grep Value | cut -d'"' -f4)
	hcsdbtruststorepassword=$(aws ssm get-parameter --region us-east-1 --name hcsdbtruststorepassword --with-decryption | grep Value | cut -d'"' -f4)
	sed -i "s/$truststore_changeme/rdstruststore.password=$hcsdbtruststorepassword/g" /www/hybris/opt_config/db.properties
	sed -i "s/$pwd_changeme/db.password=$hcsdbpassword/g" /www/hybris/opt_config/db.properties
    cd /www/hybris/bin/platform/ && . ./setantenv.sh && ant createtypesystem -DtypeSystemName=$2 > /tmp/createtypesystem.txt
elif [[ "$1" == "revertdbconfig" ]]; then
 	truststore_changeme="rdstruststore.password=<CHANGE_ME>"
	pwd_changeme="db.password=<CHANGE_ME>"
	hcsdbpassword=$(aws ssm get-parameter --region us-east-1 --name hcsdbpassword --with-decryption | grep Value | cut -d'"' -f4)
	hcsdbtruststorepassword=$(aws ssm get-parameter --region us-east-1 --name hcsdbtruststorepassword --with-decryption | grep Value | cut -d'"' -f4)
	sed -i "s/rdstruststore.password=$hcsdbtruststorepassword/$truststore_changeme/g" /www/hybris/opt_config/db.properties
	sed -i "s/db.password=$hcsdbpassword/$pwd_changeme/g" /www/hybris/opt_config/db.properties
fi