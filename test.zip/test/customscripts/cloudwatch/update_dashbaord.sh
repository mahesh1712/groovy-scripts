#!/bin/bash

instanceId=$(curl -s http://169.254.169.254/latest/meta-data/instance-id)
old_instanceIds=$1
dashboard_name="custom-dashboard"
region=$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document | grep -oP '(?<="region" : ")[^"]*(?=")')
stack=$(aws ec2 describe-instances --region ${region} --output=text --instance-ids ${instanceId} --query 'Reservations[].Instances[].[Tags[?Key==`Name`].Value]')


addAlarms=('Instance StatusCheckFailed Alarm! - '$stack'-'$instanceId 'Instance CPU Alert! '$stack'-'$instanceId 'Instance MemoryUtilization Alert! - '$stack'-'$instanceId 'Instance Storage Alert! - '$stack'-'$instanceId' - path: /')

for old_instanceId in $(echo $old_instanceIds | sed "s/,/ /g")
do
remmoveAlarms=('Instance StatusCheckFailed Alarm! - '$stack'-'$old_instanceId 'Instance CPU Alert! '$stack'-'$old_instanceId 'Instance MemoryUtilization Alert! - '$stack'-'$old_instanceId 'Instance Storage Alert! - '$stack'-'$old_instanceId' - path: /')


del_dash=$(aws cloudwatch get-dashboard --dashboard-name $dashboard_name --region "$region")
del_widgets=$(echo $del_dash | /usr/local/bin/jq -r '.DashboardBody')
	for ALARMNAMES in "${remmoveAlarms[@]}";
	do
		echo $ALARMNAMES
			data=$(echo $del_widgets | /usr/local/bin/jq --arg ALARMNAME "$ALARMNAMES" 'del(.widgets[] | select(.properties.title | contains($ALARMNAME)))')
			del_widgets=$data
	done
	del_DashboardBody=$del_widgets
	aws cloudwatch --region "$region" put-dashboard --dashboard-name  $dashboard_name --dashboard-body "$del_DashboardBody"
done




add_dash=$(aws cloudwatch get-dashboard --dashboard-name $dashboard_name --region "$region")
add_widgets=$(echo $add_dash | /usr/local/bin/jq -r '.DashboardBody')

tmp_widgets=""
for alarm_name in "${addAlarms[@]}"
do
    echo $alarm_name
    alarm_arn=$(aws cloudwatch --region "$region" describe-alarms --alarm-names "$alarm_name" --query 'MetricAlarms[0].AlarmArn')
    new_widget='[{"type":"metric","properties":{"title":"'$alarm_name'","annotations":{"alarms":['$alarm_arn']},"region":"'$region'"}}]'
    tmp_widgets=$(echo $add_widgets | /usr/local/bin/jq --argjson w "$new_widget" '.widgets += $w')
    add_widgets=${tmp_widgets}
done
add_DashboardBody=$add_widgets
aws cloudwatch --region "$region" put-dashboard --dashboard-name  $dashboard_name --dashboard-body "$add_DashboardBody"
