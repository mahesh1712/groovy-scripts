#!/bin/bash


# exit script if error is returned, or if variables not set.
set -ue

SCRIPT_PATH="${1}"
DISTRO="${2}"
custom_matrix_awsscripts="${SCRIPT_PATH}/aws-scripts-mon"
cloudwatch_cron="/etc/cron.d/cloudwatch-put-wrapper"

# get current directory
my_dir="$(dirname "$0")"

#source common functions, variables.
. "${my_dir}/setup_custom_matrix"
echo "shutdown set up  start."
distro_setup

shutdown_svc_setup ${SCRIPT_PATH}
echo "shutdown set up completd."

if [ ! -d $custom_matrix_awsscripts ]; then
        copy_scripts_to_instance ${SCRIPT_PATH}     
fi
if [ ! -f $cloudwatch_cron ]; then
	create_sync_cron ${SCRIPT_PATH}
fi

setup_aws_alarms ${SCRIPT_PATH} ${DISTRO}

install_aws_custom_metrics ${DISTRO}


. "${my_dir}/cloudwatch_alarm"











