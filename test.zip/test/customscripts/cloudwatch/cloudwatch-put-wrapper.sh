#!/bin/bash

# Configure AWS_EC2CW_META_DATA where AWS script cache instance ID

fileSystemName=$(df -Th / | awk '{print $1}' | sed -n '2 p')
export AWS_EC2CW_META_DATA=/var/run/aws-mon
if [ ! -d $AWS_EC2CW_META_DATA ]; then
    mkdir -p $AWS_EC2CW_META_DATA
fi

#/opt/hcs_cron_scripts/aws-scripts-mon/mon-put-instance-data.pl --mem-used-incl-cache-buff --mem-util --mem-used --mem-avail

BASEPATH/aws-scripts-mon/mon-put-instance-data.pl --disk-space-util --disk-path=/ ${fileSystemName} --disk-space-used --disk-space-avail --swap-util --swap-used --mem-util --mem-used --mem-avail --from-cron --auto-scaling || logger -t aws-scripts-mon "status=failed exit_code=$?"