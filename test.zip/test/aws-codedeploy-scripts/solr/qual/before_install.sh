#!/bin/bash

DEPLOY_LOG="/var/log/solar-codedeploy.log"
exec &>> $DEPLOY_LOG
echo "#########################################"
echo "# Running before_install.sh             #"
echo "#########################################"

echo "#########################################"
echo "# Jenkins Parameters added              #"

ARTIFACT=deere-solr

echo "# End of Jenkins Parameters             #"
echo "#########################################"

echo "#########################################"
echo "# Ending before_install.sh              #"
echo "#########################################"
