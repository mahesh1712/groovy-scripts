#!/bin/bash

echo "#########################################"
echo "# Running application_stop.sh           #"
echo "#########################################"

echo "Testing application_stop file run " >> /tmp/testout.log
service solr stop

echo "#########################################"
echo "# Ending application_stop.sh            #"
echo "#########################################"
