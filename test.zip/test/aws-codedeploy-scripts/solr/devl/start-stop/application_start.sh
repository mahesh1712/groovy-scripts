#!/bin/bash

echo "#########################################"
echo "# Running application_start.sh          #"
echo "#########################################"

echo "Testing application_start file run " >> /tmp/testout.log
service solr start

echo "#########################################"
echo "# Ending application_start.sh           #"
echo "#########################################"
