#!/bin/bash
#sudo su hcsuser
DEPLOY_LOG="/var/log/solar-codedeploy.log"
exec &>> $DEPLOY_LOG
echo "#########################################"
echo "# Running after_install.sh             #" 
echo "#########################################" 

echo "#########################################" 
echo "# Jenkins Parameters added              #" 

ARTIFACT=deere-solr
VERSION=ARTIFACT_VERSION
#FILE_TYPE=.zip
FILE_TYPE=.tgz

echo "# End of Jenkins Parameters             #" 
echo "#########################################" 

BASE_DIR=/www
SOLR_CORE=$BASE_DIR/solr
DEPLOY_PLATFORM=$SOLR_CORE/bin
UNZIP_DIR=$SOLR_CORE/server/solr
echo "BASE_DIR: $BASE_DIR" 
echo "SOLR_CORE: $SOLR_CORE" 
echo "DEPLOY_PLATFORM: $DEPLOY_PLATFORM" 
echo "UNZIP_DIR: $UNZIP_DIR" 
echo "# Attempting to untar /tmp/$ARTIFACT/$ARTIFACT-$VERSION$FILE_TYPE " 


chkconfig --del solr 
rm -f /etc/init.d/solr 
rm -f /etc/default/solr.in.sh 
rm -rf /www/solr 

cd /tmp
echo "Current working directory : "$(pwd) 
echo " executing tar -xzvf /tmp/$ARTIFACT/$ARTIFACT-$VERSION$FILE_TYPE --strip-components=2 solr/bin/install_solr_service.sh " 
tar -xf /tmp/$ARTIFACT/$ARTIFACT-$VERSION$FILE_TYPE --strip-components=2 solr/8.6/server/bin/install_solr_service.sh 
chmod 750 /tmp/server/bin/install_solr_service.sh
cp /tmp/$ARTIFACT/$ARTIFACT-$VERSION$FILE_TYPE /tmp/solr.tgz
tar -xf solr.tgz
cd /tmp/solr/8.6/
cp -r server solr
tar -czf solr.tgz solr
rm -rf /tmp/solr.tgz
cp solr.tgz /tmp
cd /tmp
./server/bin/install_solr_service.sh /tmp/solr.tgz  -d /var/solr -i $BASE_DIR -p 8983 -s solr -u hcssolruser 
cat /www/configure.txt >> /etc/default/solr.in.sh
service solr stop 

# Adding permissions to solr cores folder to fix issue of core creation from hybris
chown hcssolruser:hcssolrgroup /www/solr 
chown -R hcssolruser:hcssolrgroup /www/solr/*  
chown hcssolruser:hcssolrgroup /etc/default/solr.in.sh 

find /www/solr/ -name log4j-api-*.13.*.jar -delete
find /www/solr/ -name log4j-core-*.13.*.jar -delete
find /www/solr/ -name log4j-1.2-api-2.13.2.jar -delete
find /www/solr/ -name log4j-api-*.15.*.jar -delete
find /www/solr/ -name log4j-core-*.15.*.jar -delete

echo "#########################################" 
echo "# Ending after_install.sh               #" 
echo "#########################################" 

aws --region us-east-1 s3 cp $DEPLOY_LOG s3://aws-parts-ecommerce-cert2-hcs/solr-$(basename "$0")-$(date +"%Y-%m-%d-%H:%M:%s").log --sse AES256
rm -rf /tmp/*
