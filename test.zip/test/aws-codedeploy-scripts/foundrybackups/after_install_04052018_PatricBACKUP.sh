#!/bin/bash

echo "#########################################"
echo "# Running after_install.sh             #"
echo "#########################################"

CUTOVER_SET=0
ENV=CERT
DISASTER=NORMAL
DEBUG=DEBUG
HOTFOLDERPROCESSING=false
JVMROUTE=$(echo $HOSTNAME |cut -d'-' -f 5)
TASKENGINE=true

echo "Parameters:"
echo "CUTOVER_SET: $CUTOVER_SET"
echo "ENV: $ENV"
echo "DISASTER: $DISASTER"
echo "DEBUG: $DEBUG"
echo "HOTFOLDERPROCESSING: $HOTFOLDERPROCESSING"
echo "JVMROUTE: $JVMROUTE"
echo "TASKENGINE: $TASKENGINE"

if [[ "$CUTOVER_SET" = '1' ]] ; then
   TEMP_EXT_HAC_WEB_DIR=/bin/platform/ext/hac/web/webroot/WEB-INF/config
else
   TEMP_EXT_HAC_WEB_DIR=/bin/platform/ext/hac/web/webroot/WEB-INF
fi
echo "TEMP_EXT_HAC_WEB_DIR: $TEMP_EXT_HAC_WEB_DIR"

START_COMMAND_NORMAL='./hybrisserver.sh start'
START_COMMAND_DEBUG='./hybrisserver.sh debug >start.log &'
if [[ "$DEBUG" = 'DEBUG' ]] ; then
   START_COMMAND=$START_COMMAND_DEBUG
else
   START_COMMAND=$START_COMMAND_NORMAL
fi
echo "START_COMMAND: $START_COMMAND"

BASE_DIR=/www
HYBRIS_CORE=$BASE_DIR/hybrisCore
HYBRIS_RELEASE=$BASE_DIR/hybrisReleases
DEPLOY_PLATFORM=$HYBRIS_CORE/hybris/bin/platform
echo "BASE_DIR: $BASE_DIR"
echo "HYBRIS_CORE: $HYBRIS_CORE"
echo "HYBRIS_RELEASE: $HYBRIS_RELEASE"
echo "DEPLOY_PLATFORM: $DEPLOY_PLATFORM"

PROPERTY_FILE=local$ENV.properties
echo "PROPERTY_FILE: $PROPERTY_FILE"

# timestamp the builds
DATE=$(date +%Y%m%d-%H%M%S)

# create folder per release
RELEASE_DIR="$HYBRIS_RELEASE/release-$DATE"
echo "RELEASE_DIR: $RELEASE_DIR"

cd /tmp/${ARTIFACT}
mkdir -p /tmp/${ARTIFACT}/${ARTIFACT}-${VERSION}
rm -rf /tmp/${ARTIFACT}/${ARTIFACT}-${VERSION}
unzip ${ARTIFACT}-${VERSION}${FILE_TYPE} -d /tmp/${ARTIFACT}/${ARTIFACT}-${VERSION}
mv /tmp/${ARTIFACT}/${ARTIFACT}-${VERSION}/*.xml $BASE_DIR/ |true
mv /tmp/${ARTIFACT}/${ARTIFACT}-${VERSION}/*.zip $BASE_DIR/ |true
#mv /tmp/${ARTIFACT}/${ARTIFACT}-${VERSION}/*.txt $BASE_DIR/ |true
#mv /tmp/${ARTIFACT}/${ARTIFACT}-${VERSION}/hybrisServer-AllExtensions.zip $BASE_DIR/ |true
#mv /tmp/${ARTIFACT}/${ARTIFACT}-${VERSION}/hybrisServer-Platform.zip $BASE_DIR/ |true
#mv /tmp/${ARTIFACT}/${ARTIFACT}-${VERSION}/hybrisServer-Config.zip $BASE_DIR/ |true
#mv /tmp/${ARTIFACT}/${ARTIFACT}-${VERSION}/hybrisServer-License.zip $BASE_DIR/ |true
rm -rf tmp/${ARTIFACT}/${ARTIFACT}-${VERSION}

echo "##############################################################################"
echo "#  STARTING DEPLOY ON: $HOSTNAME"
echo "##############################################################################"
echo

set -e
echo "Note: The DEPLOY_PLATFORM directory ${DEPLOY_PLATFORM} will be established if missing."
echo "Removing old hybris platform"

# Create the directories even if they already exist, so that in case they do not exist, they will be created before the next remove statements run.
mkdir -p $HYBRIS_CORE/hybris/bin
mkdir -p $HYBRIS_CORE/hybris/config
rm -rf $HYBRIS_CORE/hybris/bin
rm -rf $HYBRIS_CORE/hybris/config
mkdir -p $HYBRIS_CORE/hybris/log/hybrisArchiveLogs
if [ -d "$HYBRIS_CORE/hybris/temp" ]; then
   find $HYBRIS_CORE/hybris/temp -type f -name "*.*" -mtime +30 -ls -exec /bin/rm {} \; > $HYBRIS_CORE/hybris/log/hybrisArchiveLogs/hybris-temp-delete-by-age-during-deploy-tar-$(date +\%Y\%m\%d-\%H\%M\%S).log
fi

echo "Creating directories on $HOSTNAME..."
mkdir -p $HYBRIS_CORE
mkdir -p $RELEASE_DIR
# ln -sfn $HYBRIS_RELEASE hybrisReleasesLink
mv $BASE_DIR/hybris*.zip $HYBRIS_CORE |true
cd $HYBRIS_CORE
echo "About to unzip 3 zips on $HOSTNAME:"
echo "   hybrisServer-AllExtensions.zip (.../hybris/bin/...)"
echo "   hybrisServer-Platform.zip (.../hybris/bin/platform/...)"
echo "   hybrisServer-Config.zip (.../hybris/config/...)"
unzip '*.zip' < /dev/null
rm *.zip |true
echo "mv $BASE_DIR/spring-security-config.xml $HYBRIS_CORE/hybris/$TEMP_EXT_HAC_WEB_DIR/spring-security-config.xml"
mkdir -p $HYBRIS_CORE/hybris/$TEMP_EXT_HAC_WEB_DIR/
mv $BASE_DIR/spring-security-config.xml $HYBRIS_CORE/hybris/$TEMP_EXT_HAC_WEB_DIR/spring-security-config.xml |true
#echo "mv $BASE_DIR/ruleenginebackoffice-backoffice-config.xml
#$HYBRIS_CORE/hybris/$TEMP_EXT_HAC_RULEENGINEBACKOFFICE_DIR/ruleenginebackoffice-backoffice-config.xml"
#mkdir -p $HYBRIS_CORE/hybris/$TEMP_EXT_HAC_RULEENGINEBACKOFFICE_DIR/
#mv $BASE_DIR/ruleenginebackoffice-backoffice-config.xml
#$HYBRIS_CORE/hybris/$TEMP_EXT_HAC_RULEENGINEBACKOFFICE_DIR/ruleenginebackoffice-backoffice-config.xml
cd hybris
echo "Making a temp copy of the config directory so that the ant server call does not wipe out our changes to these files."
mv config config-temp
cp -rv config-temp/localextensions.xml $DEPLOY_PLATFORM/extensions.xml |true
# OLD: ln -sfn $HYBRIS_CORE/hybris $RELEASE_DIR/core
cd $DEPLOY_PLATFORM
chmod +x setantenv.sh
. ./setantenv.sh

echo "DEBUG: Just before hac.webroot insertion ~~~."
echo "hac.webroot=/hac" >> $HYBRIS_CORE/hybris/bin/platform/resources/configtemplates/develop/local.properties
echo "DEBUG: Just after hac.webroot insertion ~~~."

echo "Calling ant server with develop template to layout the config structure, into which we will then overwrite our files."
ant server -Dmaven.update.dbdrivers=false -Dinput.template=develop < /dev/null
#echo "DEBUG: Just after ant server call ~~~."

echo "Setting custom config and property files per the environment (including dynamic replacements)."
cp -rv $HYBRIS_CORE/hybris/config-temp/* $HYBRIS_CORE/hybris/config/. |true
rm -rf $HYBRIS_CORE/hybris/config-temp

cd $HYBRIS_CORE/hybris/config/
rm -f local.properties
cp -rv "$PROPERTY_FILE" 'local.properties' |true
sed -i "s/tomcat.$JVMROUTE=DeployJobReplacesThisLineWithTheReal$JVMROUTE/tomcat.$JVMROUTE=$JVMROUTE/g" local.properties
sed -i "s/cluster.id=DeployJobReplacesThisLineWithTheRealClusterID/cluster.id=$JVMROUTE/g" local.properties
sed -i "s/task.engine.loadonstartup=DeployJobReplacesThisLineWithTheRealTaskEngineValue/task.engine.loadonstartup=$TASKENGINE/g" local.properties
sed -i "s/cluster.DeployJobReplacesThisLineWithTheRealClusterID.hotfolder.configuration.enabled=DeployJobReplacesThisLineWithTheRealHotFolderValue/cluster.$JVMROUTE.hotfolder.configuration.enabled=$HOTFOLDERPROCESSING/g" local.properties
sed -i "s/DeployJobReplacesThisLineWithTheRealDBURL/${DBURL}/g" local.properties
sed -i "s/DeployJobReplacesThisLineWithTheRealDBName/${DBNAME}/g" local.properties
sed -i "s/DeployJobReplacesThisLineWithTheRealDBUsername/${DBUSERNAME}/g" local.properties
sed -i "s/DeployJobReplacesThisLineWithTheRealDBPassword/${DBPASSWORD}/g" local.properties

sed -i "s/license.sap.sapsystem=XHY/license.sap.sapsystem=CHY/g" local.properties
sed -i "s/{~{GOOGLE_MERCHANT_ID}~}/123456/g" local.properties

#sed -i "s/{~{GOOGLE_MERCHANT_USERNAME}~}/GOOGLE_MERCHANT_USERNAME/g" local.properties
#sed -i "s/{~{GOOGLE_MERCHANT_PASSWORD}~}/GOOGLE_MERCHANT_PASSWORD/g" local.properties
#sed -i "s/{~{QMGR}~}/QMGR/g" local.properties
#sed -i "s/{~{CREATE_AN_ORDER_Q}~}/CREATE_AN_ORDER_Q/g" local.properties
#sed -i "s/{~{UPDATE_AN_ORDER_Q}~}/UPDATE_AN_ORDER_Q/g" local.properties
#sed -i "s/{~{HCI_USERID}~}/HCI_USERID/g" local.properties
#sed -i "s/{~{HCI_PASSWORD}~}/HCI_PASSWORD/g" local.properties
#sed -i "s/{~{LDAP_JNDI_CREDENTIALS}~}/LDAP_JNDI_CREDENTIALS/g" local.properties
#sed -i "s/{~{BASIC_AUTH_PASSWORD}~}/BASIC_AUTH_PASSWORD/g" local.properties
#sed -i "s/{~{LDAP_JNDI_PRINCIPAL}~}/LDAP_JNDI_PRINCIPAL/g" local.properties
#sed -i "s/{~{BASIC_AUTH_USERNAME}~}/BASIC_AUTH_USERNAME/g" local.properties
#sed -i "s/{~{CYBERSOURCE_PROFILE_ID}~}/CYBERSOURCE_PROFILE_ID/g" local.properties
#sed -i "s/{~{CYBERSOURCE_ACCESS_KEY}~}/CYBERSOURCE_ACCESS_KEY/g" local.properties
#sed -i "s/{~{CYBERSOURCE_SECRET_KEY}~}/CYBERSOURCE_SECRET_KEY/g" local.properties
#sed -i "s/{~{GOOGLE_PRIME_KEY}~}/GOOGLE_PRIME_KEY/g" local.properties
#sed -i "s/{~{KEYSTORE_PASSWORD}~}/KEYSTORE_PASSWORD/g" local.properties
#sed -i "s/{~{KEYSTORE_PRIVATE_KEY}~}/KEYSTORE_PRIVATE_KEY/g" local.properties

#sed -i -e "/DeployJobReplacesThisLineWithTheRealMailPassword/r /www/passwords/mail_password.txt" -e "/DeployJobReplacesThisLineWithTheRealMailPassword/d" local.properties || true
#sed -i -e "/DeployJobReplacesThisLineWithTheRealLDAPPassword/r /www/passwords/ldap_password.txt" -e "/DeployJobReplacesThisLineWithTheRealLDAPPassword/d" local.properties || true
#sed -i -e "/DeployJobReplacesThisLineWithTheRealCISPassword/r /www/passwords/cis_password.txt" -e "/DeployJobReplacesThisLineWithTheRealCISPassword/d" local.properties || true
#sed -i -e "/DeployJobReplacesThisLineWithTheRealHCIPassword/r /www/passwords/hci_password.txt" -e "/DeployJobReplacesThisLineWithTheRealHCIPassword/d" local.properties || true
#sed -i -e "/DeployJobReplacesThisLineWithTheRealDBPassword/r /www/passwords/db_password.txt" -e "/DeployJobReplacesThisLineWithTheRealDBPassword/d" local.properties || true
#sed -i -e "/DeployJobReplacesThisLineWithTheRealGoogleApiPassword/r /www/passwords/google_api_password.txt" -e #"/DeployJobReplacesThisLineWithTheRealGoogleApiPassword/d" local.properties || true

#sed -i -e "/DeployJobReplacesThisLineWithTheRealcybersourceSecretKey/r /www/passwords/cybersource_secretKey.txt" -e "/DeployJobReplacesThisLineWithTheRealcybersourceSecretKey/d" local.properties || true
#sed -i -e "/DeployJobReplacesThisLineWithTheRealcybersourceAccessKey/r /www/passwords/cybersource_accessKey.txt" -e "/DeployJobReplacesThisLineWithTheRealcybersourceAccessKey/d" local.properties || true
#sed -i -e "/DeployJobReplacesThisLineWithTheRealcybersourceProfileID/r /www/passwords/cybersource_profileID.txt" -e "/DeployJobReplacesThisLineWithTheRealcybersourceProfileID/d" local.properties || true

 sed -i -e "/jx61332/r /www/passwords/jmxremote_password.txt" -e "/jx61332/d"  "/www/hybrisCore/hybris/config/tomcat/conf/jmxremote.password" || true

# Eliminate the next sed db password replace line once you are confident that the localPROD.properties file being deployed will always have the search string above and not below.
sed -i -e "/DeployJobReplacesThisLineWithTheRealPassword/r /www/passwords/db_password.txt" -e "/DeployJobReplacesThisLineWithTheRealPassword/d" local.properties || true

#sed -i "s/cluster.broadcast.method.jgroups.tcp.bind_addr=DeployJobReplacesThisLineWithTheRealIPOfThisServer/cluster.broadcast.method.jgroups.tcp.bind_addr=${SVRIP}/g" local.properties

echo "Handling Wily Hostname"
sed -i "s#tomcat.javaoptions=-XX:-UseSplitVerifier -javaagent:/usr/sap/ccms/wily/Agent.jar -Dcom.wily.introscope.agentProfile=/usr/sap/ccms/wily/core/config/IntroscopeAgent_tomcat.profile -Dcom.wily.introscope.agent.agentName=JohnDeereDeployJobRelaceWithServer_-1#tomcat.javaoptions=-XX:-UseSplitVerifier -javaagent:/usr/sap/ccms/wily/Agent.jar -Dcom.wily.introscope.agentProfile=/usr/sap/ccms/wily/core/config/IntroscopeAgent_tomcat.profile -Dcom.wily.introscope.agent.agentName=$HOSTNAME_-1#g" local.properties
cd $DEPLOY_PLATFORM
# Deleting temp tomcat files from prior deployment
./hybrisserver.sh stop
rm -rf tomcat/work/*
chmod +x setantenv.sh
. ./setantenv.sh
if [ -d /www/licenses/hybris/ ]; then
   cp /www/licenses/hybris/installedSaplicenses.properties /www/hybrisCore/hybris/config/licence |true
else
   echo "#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-"
   echo "#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-"
   echo "#-#"
   echo "#-#"
   echo "#-# ERROR: Hybris licenses are expected to be pre-installed on the server before this job is run."
   echo "#-# The job/script will continue processing, in order to allow license generation on the server."
   echo "#-# Re-run this job when pre-req is met."
   echo "#-#"
   echo "#-#"
   echo "#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-"
   echo "#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-"
   sleep 10
fi

# Copy the mysql DB driver from image
cp /home/ec2-user/aws-hybris-setup/mysql-connector-java-5.1.12.jar $DEPLOY_PLATFORM/lib/dbdriver
chmod 644 $DEPLOY_PLATFORM/lib/dbdriver/mysql-connector-java-5.1.12.jar

chown -R hybris:hybris /www/*

ant server -Dmaven.update.dbdrivers=false < /dev/null

# Executing ant customize as per SAP Note 2147204
echo "Executing Ant Customize"
ant customize -Dmaven.update.dbdrivers=false < /dev/null

echo
echo "Deleting older releases..."
ls -dt $HYBRIS_RELEASE/* | tail -n +4 | xargs rm -rf

echo "Creating a PRIVATE backup WITH PASSWORDS."
# remove any lingering folders, since about to create them anyway
rm -rf $RELEASE_DIR/hybris/config
rm -rf $RELEASE_DIR/hybris/bin
rm -rf $RELEASE_DIR/hybris
# create new folders to hold a backup copy
mkdir $RELEASE_DIR/hybris
mkdir $RELEASE_DIR/hybris/config
mkdir $RELEASE_DIR/hybris/bin
chmod 700 $RELEASE_DIR
cp -rvf $HYBRIS_CORE/hybris/config/* $RELEASE_DIR/hybris/config/. |true
cp -rvf $HYBRIS_CORE/hybris/bin/* $RELEASE_DIR/hybris/bin/. |true
find $RELEASE_DIR/hybris/config -name "*.properties" -exec chmod 700 {} \;

echo "To start the appplication, use a different Jenkins job."

echo "#########################################"
echo "# Ending after_install.sh               #"
echo "#########################################"
