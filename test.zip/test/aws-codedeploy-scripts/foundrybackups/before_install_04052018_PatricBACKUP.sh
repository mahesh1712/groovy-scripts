#!/bin/bash

echo "#########################################"
echo "# Running before_install.sh             #"
echo "#########################################"

rm -rf /tmp/${ARTIFACT}

echo "#########################################"
echo "# Ending before_install.sh              #"
echo "#########################################"
