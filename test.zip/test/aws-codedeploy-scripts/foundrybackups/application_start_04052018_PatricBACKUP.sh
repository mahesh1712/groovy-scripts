#!/bin/bash

echo "#########################################"
echo "# Running before_install.sh             #"
echo "#########################################"

su -c "/www/hybrisCore/hybris/bin/platform/hybrisserver.sh start" -s /bin/sh hybris

echo "#########################################"
echo "# Ending before_install.sh              #"
echo "#########################################"
