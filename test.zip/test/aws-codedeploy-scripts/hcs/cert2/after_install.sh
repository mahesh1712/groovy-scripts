#!/bin/bash
#sudo su hcsuser

DEPLOY_LOG="/var/log/hcs-codedeploy.log"
exec &>> $DEPLOY_LOG
echo "#########################################"
echo "# Running after_install.sh             #"
echo "#########################################"

echo "#########################################"
echo "# Jenkins Parameters added              #"
MYENV=__ENV__
ARTIFACT=deere-hybris
VERSION=ARTIFACT_VERSION
FILE_TYPE=.zip
DBURL=aurora-hcsrds-db.cvbno5prg7qa.us-east-1.rds.amazonaws.com
DBNAME=hcsdb
DBUSERNAME=adyhc1t
echo "# End of Jenkins Parameters             #"
echo "#########################################"

BASE_DIR=/www
HYBRIS_CORE=${BASE_DIR}/hybris
DEPLOY_PLATFORM=${HYBRIS_CORE}/bin/platform
echo "BASE_DIR: ${BASE_DIR}"
echo "HYBRIS_CORE: ${HYBRIS_CORE}"
echo "DEPLOY_PLATFORM: ${DEPLOY_PLATFORM}"

chkconfig --del hybrisPlatform
rm -f /etc/init.d/hybrisPlatform
rm -f /etc/default/hybrisPlatform
rm -rf ${BASE_DIR}/hybris/bin
rm -rf ${BASE_DIR}/hybris/config
rm -rf ${BASE_DIR}/hybris/opt_config



#unzip /tmp/${ARTIFACT}/${ARTIFACT}-${VERSION}${FILE_TYPE} "hybrisServer*" "${MYENV}_aws*" -d /tmp
unzip -o /tmp/${ARTIFACT}/${ARTIFACT}-${VERSION}${FILE_TYPE} "hybrisServer*" "${MYENV}-opt_config*" -d /tmp
cd /tmp/
for myfile in hybrisServer*.zip; do unzip -o ${myfile} -d ${BASE_DIR} ; done
unzip ${MYENV}-opt_config.zip -d ${BASE_DIR}
#unzip ${MYENV}_aws-opt_config.zip -d ${BASE_DIR}

#licence has invalid Oracle and local values in github. Remove them
rm -rf ${HYBRIS_CORE}/config/licence/installedSaplicenses.properties

cd ${DEPLOY_PLATFORM}
echo " inside platform folder"
echo " hcsuser:hcsgroup on www"
# Cristian Popa from SAP preferred the following two lines (for OS timing reasons; don't change)
chown hcsuser:hcsgroup /www
#chown -R hcsuser:hcsgroup /www/*
echo " hcsuser:hcsgroup on www-hybris"
chown hcsuser:hcsgroup /www/hybris
echo " hcsuser:hcsgroup on www-hybris-children"
chown -R hcsuser:hcsgroup /www/hybris/*
echo "chown Script ended"


# License installation
#./license.sh -install /www/hybrislicense/CHY_Standard_AWS.txt

# Cristian Popa from SAP preferred to have ant server called at this juncture instead of below, but
# since testing never showed wrapper.conf being created until the later juncture, we are commenting out this one permanently.
#sleep 5
#su - hcsuser -c "cd ${DEPLOY_PLATFORM}; source ./setantenv.sh; ant server"

echo "starting export"
echo export y_db_password=\$\(aws ssm get-parameter --region us-east-1 --name hcsdbpasswordcert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
echo export y_rdstruststore_password=\$\(aws ssm get-parameter --region us-east-1 --name hcsdbtruststorepasswordcert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform

echo export y_hybris_security_http_basic_auth_password=\$\(aws ssm get-parameter --region us-east-1 --name hcsauthpasswordcert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
echo export y_google_api_merchantCenter_id=\$\(aws ssm get-parameter --region us-east-1 --name hcsgoogleapidcert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
echo export y_google_api_merchantCenter_sftp_password=\$\(aws ssm get-parameter --region us-east-1 --name hcsgoogleapipasswordcert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
echo export y_google_api_contentApi_serviceAccount_privateKeyFile=\$\(aws ssm get-parameter --region us-east-1 --name hcsgoogleapiprivateKeyFilecert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
echo export y_ldap_jndi_credentials=\$\(aws ssm get-parameter --region us-east-1 --name hcsldapcredentialscert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform

echo export y_sso_keystore_default_certificate_alias=\$\(aws ssm get-parameter --region us-east-1 --name hcsssokeystoredefaultcertificatealiascert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
echo export y_sso_keystore_location=\$\(aws ssm get-parameter --region us-east-1 --name hcsssokeystorelocationcert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
echo export y_sso_keystore_password=\$\(aws ssm get-parameter --region us-east-1 --name hcsssokeystorepasswordcert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
echo export y_sso_keystore_privatekey_alias=\$\(aws ssm get-parameter --region us-east-1 --name hcsssokeystoreprivatekeyaliascert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
echo export y_sso_keystore_privatekey_password=\$\(aws ssm get-parameter --region us-east-1 --name hcsssokeystoreprivatekeypasswordcert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform

echo export y_sso_privatekey_alias_backoffice=\$\(aws ssm get-parameter --region us-east-1 --name hcsssoprivatekeyaliasbackofficecert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
echo export y_sso_privatekey_alias_storefront=\$\(aws ssm get-parameter --region us-east-1 --name hcsssoprivatekeyaliasstorefrontcert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
echo export y_sso_privatekey_alias_appserver=\$\(aws ssm get-parameter --region us-east-1 --name hcsssoprivatekeyaliasappservercert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform

echo export y_salesforce_subscription_sftp_location=\$\(aws ssm get-parameter --region us-east-1 --name hcssalesforcesubsftplocationcert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform

echo export y_return_ups_password=\$\(aws ssm get-parameter --region us-east-1 --name hcsreturnupspasswordcert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
echo export y_salesforce_sftp_location=\$\(aws ssm get-parameter --region us-east-1 --name hcssalesforcesftplocationcert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
echo export y_salesforce_sftp_password=\$\(aws ssm get-parameter --region us-east-1 --name hcssalesforcesftppasswordcert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
echo export y_salesforce_sftp_username=\$\(aws ssm get-parameter --region us-east-1 --name hcssalesforcesftpusernamecert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform

echo export y_cybersource_fraud_device_finger_print_orgId=\$\(aws ssm get-parameter --region us-east-1 --name hcscybersourcefrauddevicefingerprintorgIdcert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
echo export y_hcs_truststore_password=\$\(aws ssm get-parameter --region us-east-1 --name hcstruststorepasswordcert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
echo export y_salesforce_backInStock_sftp_location=\$\(aws ssm get-parameter --region us-east-1 --name hcssalesforcebackInStocksftplocationcert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
echo export y_hybris_image_pdf_convert=\$\(aws ssm get-parameter --region us-east-1 --name hcshybrisimagepdfconvertcert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
echo export y_okta_cims_clientId=\$\(aws ssm get-parameter --region us-east-1 --name hcsoktacimsclientIdcert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
echo export y_okta_cims_clientSecret=\$\(aws ssm get-parameter --region us-east-1 --name hcsoktacimsclientSecretcert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
echo export y_app_id=\$\(aws ssm get-parameter --region us-east-1 --name hcsappidcert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
echo export y_app_password=\$\(aws ssm get-parameter --region us-east-1 --name hcsapppasswordcert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
echo export y_jms_userid=\$\(aws ssm get-parameter --region us-east-1 --name hcsmqjmsuseridcer2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform

echo export y_okta_rmi_reprogramming_authorizationserver=\$\(aws ssm get-parameter --region us-east-1 --name hcsoktarmireprogrammingauthorizationservercert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
echo export y_okta_rmi_reprogramming_clientId=\$\(aws ssm get-parameter --region us-east-1 --name hcsoktarmireprogrammingclientIdcert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
echo export y_okta_rmi_reprogramming_clientSecret=\$\(aws ssm get-parameter --region us-east-1 --name hcsoktarmireprogrammingclientSecretcert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform

echo export y_log4j_file_location=\$\(aws ssm get-parameter --region us-east-1 --name hcslog4jfilelocationcert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
echo export y_cybersource_customer_applepay_keystore_location=\$\(aws ssm get-parameter --region us-east-1 --name hcscybersourcecustomerapplepaykeystorelocationcert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
echo export y_cybersource_customer_applepay_keystore_password=\$\(aws ssm get-parameter --region us-east-1 --name hcscybersourcecustomerapplepaykeystorepasswordcert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
echo export y_cybersource_customer_applepay_merchantidentity_key_password=\$\(aws ssm get-parameter --region us-east-1 --name hcscybersourcecustomerapplepaymerchantidentitykeypasswordcert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
echo export y_cybersource_customer_applepay_payment_privatekey_password=\$\(aws ssm get-parameter --region us-east-1 --name hcscybersourcecustomerapplepaypaymentprivatekeypasswordcert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform

echo export y_delta_reports_sftp_location=\$\(aws ssm get-parameter --region us-east-1 --name hcsdeltareportssftplocationcert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform

echo export y_recaptcha_publickey=\$\(aws ssm get-parameter --region us-east-1 --name hcsrecaptchapublickey --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform

echo export y_recaptcha_privatekey=\$\(aws ssm get-parameter --region us-east-1 --name hcsrecaptchaprivatekey --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform

echo export y_occ_app_id=\$\(aws ssm get-parameter --region us-east-1 --name hcspartscheckoutdealerappidcert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform

SAMLKEY=/opt/local/etc/hybris/samlKeystoreHybris.jks
APPLEPAYKEYSTORE=/opt/local/etc/hybris/JDStoreApplePayMerchantIdentifierSandbox.jks
echo "======="
echo $VERSION
echo "======="


echo export y_payeezy_developer_apikey=\$\(aws ssm get-parameter --region us-east-1 --name hcspayeezydeveloperapikeycert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
echo export y_payeezy_developer_apisecret=\$\(aws ssm get-parameter --region us-east-1 --name hcspayeezydeveloperapisecretcert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
echo export y_payeezy_developer_merchanttoken=\$\(aws ssm get-parameter --region us-east-1 --name hcspayeezydevelopermerchanttokencert2 --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
if [ -f "$SAMLKEY" ]; then
	echo "samlKeystoreHybris.jks file copying 2"
	if [ ${VERSION} = "1.0-SNAPSHOT" ] ; then
        cp -i /opt/local/etc/hybris/samlKeystoreHybris.jks /www/hybris/bin/ext-integration/samlsinglesignon/web/webroot/WEB-INF/security/
		chown hcsuser:hcsgroup /www/hybris/bin/ext-integration/samlsinglesignon/web/webroot/WEB-INF/security/samlKeystoreHybris.jks
    fi
	if [ ${VERSION} = "1.1-SNAPSHOT" ] ; then
		cp -i /opt/local/etc/hybris/samlKeystoreHybris.jks /www/hybris/bin/modules/platform/samlsinglesignon/web/webroot/WEB-INF/security
		chown hcsuser:hcsgroup /www/hybris/bin/modules/platform/samlsinglesignon/web/webroot/WEB-INF/security/samlKeystoreHybris.jks	
	fi
else
        echo "please check the saml keystore file."
fi
if [ -f "$APPLEPAYKEYSTORE" ]; then
	echo "JDStoreApplePayMerchantIdentifierSandbox.jks file copying 2"
	cp -i /opt/local/etc/hybris/JDStoreApplePayMerchantIdentifierSandbox.jks /www/hybris/bin/custom/HybrisMarketPlace/cybersourcepaymentaddon/resources/cybersourcepaymentaddon/applepay/keystores/cybersourceDecryption/
	chown hcsuser:hcsgroup /www/hybris/bin/custom/HybrisMarketPlace/cybersourcepaymentaddon/resources/cybersourcepaymentaddon/applepay/keystores/cybersourceDecryption/JDStoreApplePayMerchantIdentifierSandbox.jks
else
	echo "please check the apple pay keystore file."
fi


#export y_db_password=$(aws ssm get-parameter --region us-east-1 --name hcsdb.password --with-decryption | grep Value | awk -F '"' '{print $4}')
#export private_key=$(aws ssm get-parameter --region us-east-1 --name hcsgoogleapi.privatekey --with-decryption | grep Value | awk -F '"' '{print $4}')
#export private_key_id=$(aws ssm get-parameter --region us-east-1 --name hcsgoogleapi.privatekeyid --with-decryption | grep Value | awk -F '"' '{print $4}')
#export jmx_password=$(aws ssm get-parameter --region us-east-1 --name hcsjmx.password --with-decryption | grep Value | awk -F '"' '{print $4}')
#export keystore_pass=$(aws ssm get-parameter --region us-east-1 --name hcskeysore.pass --with-decryption | grep Value | awk -F '"' '{print $4}')
export private_key=$(aws ssm get-parameter --region us-east-1 --name hcsgoogleapiprivatekeycert2 --with-decryption | grep Value | awk -F '"' '{print $4}')
export private_key_id=$(aws ssm get-parameter --region us-east-1 --name hcsgoogleapiprivatekeyidcert2 --with-decryption | grep Value | awk -F '"' '{print $4}')
export jmx_password=$(aws ssm get-parameter --region us-east-1 --name hcsjmxpasswordcert2 --with-decryption | grep Value | awk -F '"' '{print $4}')
export keystore_pass=$(aws ssm get-parameter --region us-east-1 --name hcskeysorepasscert2 --with-decryption | grep Value | awk -F '"' '{print $4}')


echo "################TEMPORARY CHANGES  THIS WILL BE CHECKED INTO REPO LATER  #########################"
#DBURL AND DETAILS CHECKED INTO GITHUB REPO IN env/devl/db.properties HENCE THIS IS COMMENETED OUT
#cat << EOF > ${HYBRIS_CORE}/opt_config/db.properties
#db.url=jdbc:mysql://aurora-hcsrds-db.cvbno5prg7qa.us-east-1.rds.amazonaws.com/hcsdb?useConfigs=maxPerformance&rewriteBatchedStatements=true&characterEncoding=utf8&useSSL=false
#db.username=adyhc1t
#db.password=<CHANGE_ME>
#EOF

# task.engine.loadonstartup=DeployJobReplacesThisLineWithTheRealTaskEngineValue  needs to be added with correct value to userdata for storefront and backoffice and move the file from tmp to nodes.
#echo "task.engine.loadonstartup=true" > ${HYBRIS_CORE}/opt_config/nodes/backoffice.properties
#echo "task.engine.loadonstartup=false" > ${HYBRIS_CORE}/opt_config/nodes/storefront.properties
#chown hcsuser:hcsgroup ${HYBRIS_CORE}/opt_config/nodes/backoffice.properties
#chown hcsuser:hcsgroup ${HYBRIS_CORE}/opt_config/nodes/storefront.properties

#Storefront.properties and backoffice.properties are checked into Github now under env/devl
#cp /www/taskengineconfig/taskengine.properties ${HYBRIS_CORE}/opt_config/nodes/backoffice.properties
#chown hcsuser:hcsgroup ${HYBRIS_CORE}/opt_config/nodes/backoffice.properties
#cp /www/taskengineconfig/taskengine.properties ${HYBRIS_CORE}/opt_config/nodes/storefront.properties
#chown hcsuser:hcsgroup ${HYBRIS_CORE}/opt_config/nodes/storefront.properties

sed -i '/###\ END\ INIT\ INFO/!b;n;csource \/etc\/default\/hybrisPlatform' ${DEPLOY_PLATFORM}/tomcat/bin/wrapper.sh
echo "################END OF TEMPORARY CHANGES  THIS WILL BE CHECKED INTO REPO LATER  #########################"

echo "################START DEPLOY JOB REPLACEMENTS  #########################"
sed -i "s|DeployJobReplacesThisLineWithTheRealPrivateKeyTest|${private_key}|g" ${HYBRIS_CORE}/config/TestProejct-e40bd3267e1c.json
sed -i "s|DeployJobReplacesThisLineWithTheRealPrivateKeyIdTest|${private_key_id}|g" ${HYBRIS_CORE}/config/TestProejct-e40bd3267e1c.json
sed -i "s|DeployJobReplacesThisLineWithTheRealKeystorePass|${keystore_pass}|g" ${HYBRIS_CORE}/config/tomcat/conf/server.xml
sed -i "s|DeployJobReplacesThisLineWithTheRealKeystorePass|${keystore_pass}|g" ${HYBRIS_CORE}/config/tomcat/conf/server-minimal.xml
sed -i "s|mail.pop3.password=<CHANGE_ME>|mail.pop3.password=|g" ${HYBRIS_CORE}/config/local.properties
sed -i "s|DeployJobReplacesThisLineWithTheRealJmxRemotePassword|${jmx_password}|g" ${HYBRIS_CORE}/config/tomcat/conf/jmxremote.password
sed -i "s|DeployJobReplacesThisLineWithTheRealSFTPUsername|${sftp_username}|g" ${HYBRIS_CORE}/config/local.properties
sed -i "s|DeployJobReplacesThisLineWithTheRealSFTPPassword|${sftp_password}|g" ${HYBRIS_CORE}/config/local.properties
sed -i "s|DeployJobReplacesThisLineWithTheRealSFTPLocation|${sftp_location}|g" ${HYBRIS_CORE}/config/local.properties
sed -i "s|DeployJobReplacesThisLineWithTheRealReturnUPSPassword|${UPS_password}|g" ${HYBRIS_CORE}/config/local.properties

#sed -i "s/DeployJobReplacesThisLineWithTheRealPrivateKeyTest/${private_key}/g" ${HYBRIS_CORE}/config/TestProejct-e40bd3267e1c.json
#sed -i "s/DeployJobReplacesThisLineWithTheRealPrivateKeyIdTest/${private_key_id}/g" ${HYBRIS_CORE}/config/TestProejct-e40bd3267e1c.json
#sed -i "s/DeployJobReplacesThisLineWithTheRealJmxRemotePassword/${jmx_password}/g" ${HYBRIS_CORE}/config/tomcat/conf/jmxremote.password
#sed -i "s/keystorePass=<CHANGE_ME>/keystorePass=${keystore_pass}/g" ${HYBRIS_CORE}/config/tomcat/conf/server.xml
#sed -i "s/DeployJobReplacesThisLineWithTheRealKeystorePass/${keystore_pass}/g" ${HYBRIS_CORE}/config/tomcat/conf/server-minimal.xml
#sed -i "s/ldap.jndi.credentials=<CHANGE_ME>/ldap.jndi.credentials=${ldap_jndi_cred}/g" ${HYBRIS_CORE}/config/local.properties
#sed -i "s/mail.pop3.password=<CHANGE_ME>/mail.pop3.password=/g" ${HYBRIS_CORE}/config/local.properties

#echo "######################### Create rds truststore #########################"
#aws --region us-east-1 s3 cp s3://aws-parts-ecommerce-cert2-hcs/rds/ssl_public_key/rds-combined-ca-bundle.pem /opt/local/etc/hybris/rds-combined-ca-bundle.pem
#[ -e /opt/local/etc/hybris/JDStoreRDSTrustStore ] && rm -f /opt/local/etc/hybris/JDStoreRDSTrustStore
#rdstruststorepassword=$(aws ssm get-parameter --region us-east-1 --name hcsdbtruststorepassword --with-decryption | grep Value | awk -F '"' '{print \$4}' )
#/usr/bin/keytool -keystore /opt/local/etc/hybris/JDStoreRDSTrustStore -importcert -alias MySQLCACert -file /opt/local/etc/hybris/rds-combined-ca-bundle.pem -storepass $rdstruststorepassword <<< "yes"
#chown hcsuser:hcsgroup /opt/local/etc/hybris/JDStoreRDSTrustStore
#rm -f /opt/local/etc/hybris/rds-combined-ca-bundle.pem

echo "################END DEPLOY JOB REPLACEMENTS   #########################"


echo "START REVIEW: FOLLOWING SECTION NEEDS CRISTIAN'S REVIEW..."
# ALTERNATIVE APPROACH: /sbin/ifconfig eth0 | grep 'inet addr' | cut -d: -f2 | awk '{print $1}'
PRIVATEIP=$(curl http://169.254.169.254/latest/dynamic/instance-identity/document | grep privateIp |awk -F\\\" '{print $4}')
CLUSTERID=$(echo "${PRIVATEIP}" | cut -d "." -f 4)
# Remove next line and this comment when real Deere configuration is added.  This next line only needed for lighty version.
echo "cluster.id=DeployJobReplacesThisLineWithTheRealClusterID" >> ${HYBRIS_CORE}/config/local.properties
sed -i "s/cluster.id=DeployJobReplacesThisLineWithTheRealClusterID/cluster.id=${CLUSTERID}/g" ${HYBRIS_CORE}/config/local.properties
echo "tomcat.jvmroute=DeployJobReplacesThisLineWithTheRealJVMRoute" >> ${HYBRIS_CORE}/config/local.properties
sed -i "s/tomcat.jvmroute=DeployJobReplacesThisLineWithTheRealJVMRoute/tomcat.jvmroute=${CLUSTERID}/g" ${HYBRIS_CORE}/config/local.properties
# Setting hotfolder to enabled on both backoffice nodes until we have a way to set it only in one.
sed -i "s|DeployJobReplacesThisLineWithTheRealClusterID|${CLUSTERID}|g" ${HYBRIS_CORE}/opt_config/nodes/backoffice.properties
sed -i "s|DeployJobReplacesThisLineWithTheRealHotFolderValue|true|g" ${HYBRIS_CORE}/opt_config/nodes/backoffice.properties
sed -i "s|DeployJobReplacesThisLineWithTheRealHotFolderValue|false|g" ${HYBRIS_CORE}/opt_config/nodes/storefront.properties
echo "END REVIEW: ABOVE SECTION NEEDS CRISTIAN'S REVIEW."

find /www/hybris/ -name log4j-api-*.13.*.jar -delete
find /www/hybris/ -name log4j-core-*.13.*.jar -delete
find /www/hybris/ -name log4j-1.2-api-2.13.2.jar -delete
find /www/hybris/ -name log4j-api-*.15.*.jar -delete
find /www/hybris/ -name log4j-core-*.15.*.jar -delete

if [ -f "/www/hybris/config/customize/modules/search-and-navigation/solrserver/resources/solr/8.6/server/server/lib/ext/log4j-api-2.17.0.jar" ]; then
 cp /www/hybris/config/customize/modules/search-and-navigation/solrserver/resources/solr/8.6/server/server/lib/ext/log4j-api-2.17.0.jar /www/hybris/bin/platform/ext/core/lib/
else
	echo "log4j-api-2.17.0.jar"
fi

if [ -f "/www/hybris/config/customize/modules/search-and-navigation/solrserver/resources/solr/8.6/server/server/lib/ext/log4j-core-2.17.0.jar" ]; then
 cp /www/hybris/config/customize/modules/search-and-navigation/solrserver/resources/solr/8.6/server/server/lib/ext/log4j-core-2.17.0.jar /www/hybris/bin/platform/ext/core/lib/
else
	echo "log4j-core-2.17.0.jar"
fi

cd ${DEPLOY_PLATFORM}/tomcat/bin
./wrapper.sh install
echo "TRACING ~~~ AFTER WRAPPER INSTALL"

echo "LICENSE INSTALLATION ~~~ BEFORE INSTALL"
su - hcsuser -c "aws --region us-east-1 s3 cp s3://aws-parts-ecommerce-${MYENV}-hcs/hybris_license/installedSaplicenses.properties /www/hybris/config/licence/installedSaplicenses.properties;"
#su - hcsuser -c "aws --region us-east-1 s3 cp s3://aws-parts-ecommerce-devl-hcs/hybris_license/devl/CHY_Standard_AWS.txt /www/hybrislicense/CHY_Standard_AWS.txt;"
#su - hcsuser -c "cd ${DEPLOY_PLATFORM};./license.sh -install /www/hybrislicense/CHY_Standard_AWS.txt"
echo "LICENSE INSTALLATION ~~~ AFTER INSTALL"

su - hcsuser -c "cd ${DEPLOY_PLATFORM}; source ./setantenv.sh; ant server"
echo "TRACING ~~~ AFTER ANT SERVER"

echo "#########################################"
echo "# Ending after_install.sh               #"
echo "#########################################"

aws --region us-east-1 s3 cp ${DEPLOY_LOG} s3://aws-parts-ecommerce-${MYENV}-hcs/hcs-$(basename "$0")-$(date +"%Y-%m-%d-%H:%M:%s").log --sse AES256
#Commented out temp clean up. This is moved to before_install.sh
#rm -rf /tmp/*
