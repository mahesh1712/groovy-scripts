#!/bin/bash
#sudo su hcsuser
MYLOG=/tmp/hcs-codedeploy.log
echo "#########################################" > ${MYLOG}
echo "# Running after_install.sh             #" >> ${MYLOG}
echo "#########################################" >> ${MYLOG}

echo "#########################################" >> ${MYLOG}
echo "# Jenkins Parameters added              #" >> ${MYLOG}
MYENV=__ENV__
ARTIFACT=deere-hybris
VERSION=1.0-SNAPSHOT
FILE_TYPE=.zip
DBURL=aurora-hcsrds-db.cvbno5prg7qa.us-east-1.rds.amazonaws.com
DBNAME=hcsdb
DBUSERNAME=adyhc1t
echo "# End of Jenkins Parameters             #" >> ${MYLOG}
echo "#########################################" >> ${MYLOG}

BASE_DIR=/www
HYBRIS_CORE=${BASE_DIR}/hybris
DEPLOY_PLATFORM=${HYBRIS_CORE}/bin/platform
echo "BASE_DIR: ${BASE_DIR}" >> ${MYLOG}
echo "HYBRIS_CORE: ${HYBRIS_CORE}" >> ${MYLOG}
echo "DEPLOY_PLATFORM: ${DEPLOY_PLATFORM}" >> ${MYLOG}

chkconfig --del hybrisPlatform >> ${MYLOG}
rm -f /etc/init.d/hybrisPlatform >> ${MYLOG}
rm -f /etc/default/hybrisPlatform >> ${MYLOG}
rm -rf ${BASE_DIR}/hybris/bin >> ${MYLOG}
rm -rf ${BASE_DIR}/hybris/config >> ${MYLOG}
rm -rf ${BASE_DIR}/hybris/opt_config >> ${MYLOG}



#unzip /tmp/${ARTIFACT}/${ARTIFACT}-${VERSION}${FILE_TYPE} "hybrisServer*" "${MYENV}_aws*" -d /tmp >> ${MYLOG}
unzip /tmp/${ARTIFACT}/${ARTIFACT}-${VERSION}${FILE_TYPE} "hybrisServer*" "${MYENV}-opt_config*" -d /tmp >> ${MYLOG}
cd /tmp/ >> ${MYLOG}
for myfile in hybrisServer*.zip; do unzip ${myfile} -d ${BASE_DIR} >> ${MYLOG}; done
unzip ${MYENV}-opt_config.zip -d ${BASE_DIR} >> ${MYLOG}
#unzip ${MYENV}_aws-opt_config.zip -d ${BASE_DIR} >> ${MYLOG}

#licence has invalid Oracle and local values in github. Remove them
rm -rf ${HYBRIS_CORE}/config/licence/installedSaplicenses.properties

cd ${DEPLOY_PLATFORM} >> ${MYLOG}
# Cristian Popa from SAP preferred the following two lines (for OS timing reasons; don't change)
chown hcsuser:hcsgroup /www >> ${MYLOG}
chown -R hcsuser:hcsgroup /www/* >> ${MYLOG}


# License installation
#./license.sh -install /www/hybrislicense/CHY_Standard_AWS.txt

# Cristian Popa from SAP preferred to have ant server called at this juncture instead of below, but
# since testing never showed wrapper.conf being created until the later juncture, we are commenting out this one permanently.
#sleep 5
#su - hcsuser -c "cd ${DEPLOY_PLATFORM}; source ./setantenv.sh; ant server"

echo export y_db_password=\$\(aws ssm get-parameter --region us-east-1 --name hcsdbpassword --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform

echo export y_hybris_security_http_basic_auth_password=\$\(aws ssm get-parameter --region us-east-1 --name hcsauthpassword --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
echo export y_google_api_merchantCenter_id=\$\(aws ssm get-parameter --region us-east-1 --name hcsgoogleapiid --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
echo export y_google_api_merchantCenter_sftp_password=\$\(aws ssm get-parameter --region us-east-1 --name hcsgoogleapipassword --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
echo export y_google_api_contentApi_serviceAccount_privateKeyFile=\$\(aws ssm get-parameter --region us-east-1 --name hcsgoogleapiprivateKeyFile --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform
echo export y_ldap_jndi_credentials=\$\(aws ssm get-parameter --region us-east-1 --name hcsldapcredentials --with-decryption \| grep Value \| awk -F \'\"\' \'{print \$4}\' \) >>  /etc/default/hybrisPlatform


#export y_db_password=$(aws ssm get-parameter --region us-east-1 --name hcsdb.password --with-decryption | grep Value | awk -F '"' '{print $4}')
#export private_key=$(aws ssm get-parameter --region us-east-1 --name hcsgoogleapi.privatekey --with-decryption | grep Value | awk -F '"' '{print $4}')
#export private_key_id=$(aws ssm get-parameter --region us-east-1 --name hcsgoogleapi.privatekeyid --with-decryption | grep Value | awk -F '"' '{print $4}')
#export jmx_password=$(aws ssm get-parameter --region us-east-1 --name hcsjmx.password --with-decryption | grep Value | awk -F '"' '{print $4}')
#export keystore_pass=$(aws ssm get-parameter --region us-east-1 --name hcskeysore.pass --with-decryption | grep Value | awk -F '"' '{print $4}')
export private_key=$(aws ssm get-parameter --region us-east-1 --name hcsgoogleapiprivatekey --with-decryption | grep Value | awk -F '"' '{print $4}')
export private_key_id=$(aws ssm get-parameter --region us-east-1 --name hcsgoogleapiprivatekeyid --with-decryption | grep Value | awk -F '"' '{print $4}')
export jmx_password=$(aws ssm get-parameter --region us-east-1 --name hcsjmxpassword --with-decryption | grep Value | awk -F '"' '{print $4}')
export keystore_pass=$(aws ssm get-parameter --region us-east-1 --name hcskeysorepass --with-decryption | grep Value | awk -F '"' '{print $4}')


echo "################TEMPORARY CHANGES  THIS WILL BE CHECKED INTO REPO LATER  #########################" >> ${MYLOG}
#DBURL AND DETAILS CHECKED INTO GITHUB REPO IN env/qual/db.properties HENCE THIS IS COMMENETED OUT
#cat << EOF > ${HYBRIS_CORE}/opt_config/db.properties
#db.url=jdbc:mysql://aurora-hcsrds-db.cvbno5prg7qa.us-east-1.rds.amazonaws.com/hcsdb?useConfigs=maxPerformance&rewriteBatchedStatements=true&characterEncoding=utf8&useSSL=false
#db.username=adyhc1t
#db.password=<CHANGE_ME>
#EOF

# task.engine.loadonstartup=DeployJobReplacesThisLineWithTheRealTaskEngineValue  needs to be added with correct value to userdata for storefront and backoffice and move the file from tmp to nodes.
#echo "task.engine.loadonstartup=true" > ${HYBRIS_CORE}/opt_config/nodes/backoffice.properties
#echo "task.engine.loadonstartup=false" > ${HYBRIS_CORE}/opt_config/nodes/storefront.properties
#chown hcsuser:hcsgroup ${HYBRIS_CORE}/opt_config/nodes/backoffice.properties
#chown hcsuser:hcsgroup ${HYBRIS_CORE}/opt_config/nodes/storefront.properties

#Storefront.properties and backoffice.properties are checked into Github now under env/qual
#cp /www/taskengineconfig/taskengine.properties ${HYBRIS_CORE}/opt_config/nodes/backoffice.properties
#chown hcsuser:hcsgroup ${HYBRIS_CORE}/opt_config/nodes/backoffice.properties
#cp /www/taskengineconfig/taskengine.properties ${HYBRIS_CORE}/opt_config/nodes/storefront.properties
#chown hcsuser:hcsgroup ${HYBRIS_CORE}/opt_config/nodes/storefront.properties

sed -i '/###\ END\ INIT\ INFO/!b;n;csource \/etc\/default\/hybrisPlatform' ${DEPLOY_PLATFORM}/tomcat/bin/wrapper.sh
echo "################END OF TEMPORARY CHANGES  THIS WILL BE CHECKED INTO REPO LATER  #########################" >> ${MYLOG}

echo "################START DEPLOY JOB REPLACEMENTS  #########################" >> ${MYLOG}
sed -i "s|DeployJobReplacesThisLineWithTheRealPrivateKeyTest|${private_key}|g" ${HYBRIS_CORE}/config/TestProejct-e40bd3267e1c.json
sed -i "s|DeployJobReplacesThisLineWithTheRealPrivateKeyIdTest|${private_key_id}|g" ${HYBRIS_CORE}/config/TestProejct-e40bd3267e1c.json
sed -i "s|DeployJobReplacesThisLineWithTheRealKeystorePass|${keystore_pass}|g" ${HYBRIS_CORE}/config/tomcat/conf/server.xml
sed -i "s|DeployJobReplacesThisLineWithTheRealKeystorePass|${keystore_pass}|g" ${HYBRIS_CORE}/config/tomcat/conf/server-minimal.xml
sed -i "s|mail.pop3.password=<CHANGE_ME>|mail.pop3.password=|g" ${HYBRIS_CORE}/config/local.properties
sed -i "s|DeployJobReplacesThisLineWithTheRealJmxRemotePassword|${jmx_password}|g" ${HYBRIS_CORE}/config/tomcat/conf/jmxremote.password


#sed -i "s/DeployJobReplacesThisLineWithTheRealPrivateKeyTest/${private_key}/g" ${HYBRIS_CORE}/config/TestProejct-e40bd3267e1c.json
#sed -i "s/DeployJobReplacesThisLineWithTheRealPrivateKeyIdTest/${private_key_id}/g" ${HYBRIS_CORE}/config/TestProejct-e40bd3267e1c.json
#sed -i "s/DeployJobReplacesThisLineWithTheRealJmxRemotePassword/${jmx_password}/g" ${HYBRIS_CORE}/config/tomcat/conf/jmxremote.password
#sed -i "s/keystorePass=<CHANGE_ME>/keystorePass=${keystore_pass}/g" ${HYBRIS_CORE}/config/tomcat/conf/server.xml
#sed -i "s/DeployJobReplacesThisLineWithTheRealKeystorePass/${keystore_pass}/g" ${HYBRIS_CORE}/config/tomcat/conf/server-minimal.xml
#sed -i "s/ldap.jndi.credentials=<CHANGE_ME>/ldap.jndi.credentials=${ldap_jndi_cred}/g" ${HYBRIS_CORE}/config/local.properties
#sed -i "s/mail.pop3.password=<CHANGE_ME>/mail.pop3.password=/g" ${HYBRIS_CORE}/config/local.properties

echo "################END DEPLOY JOB REPLACEMENTS   #########################" >> ${MYLOG}


echo "START REVIEW: FOLLOWING SECTION NEEDS CRISTIAN'S REVIEW..."
# ALTERNATIVE APPROACH: /sbin/ifconfig eth0 | grep 'inet addr' | cut -d: -f2 | awk '{print $1}'
PRIVATEIP=$(curl http://169.254.169.254/latest/dynamic/instance-identity/document | grep privateIp |awk -F\\\" '{print $4}')
CLUSTERID=$(echo "${PRIVATEIP}" | cut -d "." -f 4)
# Remove next line and this comment when real Deere configuration is added.  This next line only needed for lighty version.
echo "cluster.id=DeployJobReplacesThisLineWithTheRealClusterID" >> ${HYBRIS_CORE}/config/local.properties
sed -i "s/cluster.id=DeployJobReplacesThisLineWithTheRealClusterID/cluster.id=${CLUSTERID}/g" ${HYBRIS_CORE}/config/local.properties
echo "tomcat.jvmroute=DeployJobReplacesThisLineWithTheRealJVMRoute" >> ${HYBRIS_CORE}/config/local.properties
sed -i "s/tomcat.jvmroute=DeployJobReplacesThisLineWithTheRealJVMRoute/tomcat.jvmroute=${CLUSTERID}/g" ${HYBRIS_CORE}/config/local.properties
# Setting hotfolder to enabled on both backoffice nodes until we have a way to set it only in one.
sed -i "s|DeployJobReplacesThisLineWithTheRealClusterID|${CLUSTERID}|g" ${HYBRIS_CORE}/opt_config/nodes/backoffice.properties
sed -i "s|DeployJobReplacesThisLineWithTheRealHotFolderValue|true|g" ${HYBRIS_CORE}/opt_config/nodes/backoffice.properties
echo "END REVIEW: ABOVE SECTION NEEDS CRISTIAN'S REVIEW."



cd ${DEPLOY_PLATFORM}/tomcat/bin
./wrapper.sh install
echo "TRACING ~~~ AFTER WRAPPER INSTALL" >> ${MYLOG}

echo "LICENSE INSTALLATION ~~~ BEFORE INSTALL" >> ${MYLOG}
su - hcsuser -c "aws --region us-east-1 s3 cp s3://aws-parts-ecommerce-${MYENV}-hcs/hybris_license/installedSaplicenses.properties /www/hybris/config/licence/installedSaplicenses.properties;"
#su - hcsuser -c "aws --region us-east-1 s3 cp s3://aws-parts-ecommerce-qual-hcs/hybris_license/qual/CHY_Standard_AWS.txt /www/hybrislicense/CHY_Standard_AWS.txt;"
#su - hcsuser -c "cd ${DEPLOY_PLATFORM};./license.sh -install /www/hybrislicense/CHY_Standard_AWS.txt"
echo "LICENSE INSTALLATION ~~~ AFTER INSTALL" >> ${MYLOG}

su - hcsuser -c "cd ${DEPLOY_PLATFORM}; source ./setantenv.sh; ant server"
echo "TRACING ~~~ AFTER ANT SERVER" >> ${MYLOG}

echo "#########################################" >> ${MYLOG}
echo "# Ending after_install.sh               #" >> ${MYLOG}
echo "#########################################" >> ${MYLOG}

aws --region us-east-1 s3 cp ${MYLOG} s3://aws-parts-ecommerce-${MYENV}-hcs/hcs-$(basename "$0")-$(date +"%Y-%m-%d-%H:%M:%s").log >> ${MYLOG}
rm -rf /tmp/*
