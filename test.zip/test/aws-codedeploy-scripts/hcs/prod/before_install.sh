#!/bin/bash

DEPLOY_LOG="/var/log/hcs-codedeploy.log"
exec &>> $DEPLOY_LOG
echo "#########################################"
echo "# Running before_install.sh             #"
echo "#########################################"

echo "#########################################"
echo "# Jenkins Parameters added              #"

ARTIFACT=deere-hybris
rm -rf /tmp/*
#rm -rf /tmp/hybrisServer*
#rm -rf /tmp/prod-opt_config.zip

echo "# End of Jenkins Parameters             #"
echo "#########################################"


echo "#########################################"
echo "# Ending before_install.sh              #"
echo "#########################################"
