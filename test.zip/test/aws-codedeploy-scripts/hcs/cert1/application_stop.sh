#!/bin/bash

DEPLOY_LOG="/var/log/hcs-codedeploy.log"
#minimumsize="2147483648"
#actualsize=$(wc -c <"$DEPLOY_LOG")
#if [ $actualsize -ge $minimumsize ]; then
#	rm $DEPLOY_LOG
 #   exec &> $DEPLOY_LOG
	#date +"%Y-%m-%d-%H:%M:%S"
#else
 #   exec &>> $DEPLOY_LOG
	#date +"%Y-%m-%d-%H:%M:%S"
#fi
exec &> $DEPLOY_LOG
current_date=$(date +"%Y-%m-%d-%H:%M:%S")
echo "Deployment Started at $current_date"
echo "#########################################"
echo "# Running application_stop.sh           #"
echo "#########################################"

echo "Testing application_stop file run "
service hybrisPlatform stop

echo "#########################################"
echo "# Ending application_stop.sh            #"
echo "#########################################"
