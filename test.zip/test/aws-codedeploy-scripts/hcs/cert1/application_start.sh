#!/bin/bash

DEPLOY_LOG="/var/log/hcs-codedeploy.log"
exec &>> $DEPLOY_LOG
echo "#########################################"
echo "# Running application_start.sh          #"
echo "#########################################"

echo " --------------------Configuring AppDynamics Start --------------------"
#Appdynamics changes

TIERNAME=hybrisawscert1.deere.com
PRIVATEIP=$(curl http://169.254.169.254/latest/dynamic/instance-identity/document | grep privateIp |awk -F\\\" '{print $4}')
if [ ${DEPLOYMENT_GROUP_NAME}  == 'hcsbocert1-deployment-group' ]
then
  TIERNAME=hybrisawsinternalcert1.deere.com
fi

#Configuring wrapper
echo "wrapper.java.additional.34=-javaagent:/opt/appdynamics/java-agent/ver20.4.0.29862/javaagent.jar" >> /www/hybris/bin/platform/tomcat/conf/wrapper.conf
echo "wrapper.java.additional.35=-Dappdynamics.agent.applicationName=JDStoreAWSNonProd" >> /www/hybris/bin/platform/tomcat/conf/wrapper.conf
#echo "wrapper.java.additional.36=-Dappdynamics.agent.tierName=hybrisawsinternalcert1.deere.com" >> /www/hybris/bin/platform/tomcat/conf/wrapper.conf
echo "wrapper.java.additional.36=-Dappdynamics.agent.tierName=${TIERNAME}" >> /www/hybris/bin/platform/tomcat/conf/wrapper.conf
echo "wrapper.java.additional.37=-Dappdynamics.agent.reuse.nodeName=false" >> /www/hybris/bin/platform/tomcat/conf/wrapper.conf

#Configuring java-agent
sed -i "s|<controller-host>deere.saas.appdynamics.com</controller-host>|<controller-host>deere-nonprod.saas.appdynamics.com</controller-host>|g" /opt/appdynamics/java-agent/ver20.4.0.29862/conf/controller-info.xml
sed -i "s|<controller-port>80</controller-port>|<controller-port>443</controller-port>|g" /opt/appdynamics/java-agent/ver20.4.0.29862/conf/controller-info.xml
sed -i "s|<controller-ssl-enabled>false</controller-ssl-enabled>|<controller-ssl-enabled>true</controller-ssl-enabled>|g" /opt/appdynamics/java-agent/ver20.4.0.29862/conf/controller-info.xml
sed -i "s|<application-name></application-name>|<application-name>JDStoreAWSNonProd</application-name>|g" /opt/appdynamics/java-agent/ver20.4.0.29862/conf/controller-info.xml
#sed -i "s|<tier-name></tier-name>|<tier-name>hybrisawsinternalcert1.deere.com</tier-name>|g" /opt/appdynamics/java-agent/ver20.4.0.29862/conf/controller-info.xml
sed -i "s|<tier-name></tier-name>|<tier-name>${TIERNAME}</tier-name>|g" /opt/appdynamics/java-agent/ver20.4.0.29862/conf/controller-info.xml
sed -i "s|<node-name></node-name>|<node-name>${PRIVATEIP}</node-name>|g" /opt/appdynamics/java-agent/ver20.4.0.29862/conf/controller-info.xml
sed -i "s|<account-name>Deere</account-name>|<account-name>deere-nonprod</account-name>|g" /opt/appdynamics/java-agent/ver20.4.0.29862/conf/controller-info.xml

export appdaccess_key=$(aws ssm get-parameter --region us-east-1 --name hcsappdynamicsaccesskeycert1 --with-decryption | grep Value | awk -F '"' '{print $4}')
sed -i "s|<account-access-key>dfa486b5-d943-48c8-81f4-6e737fe70e04</account-access-key>|<account-access-key>${appdaccess_key}</account-access-key>|g" /opt/appdynamics/java-agent/ver20.4.0.29862/conf/controller-info.xml

#Configuring machine-agent
sed -i "s|<controller-host>deere.saas.appdynamics.com</controller-host>|<controller-host>deere-nonprod.saas.appdynamics.com</controller-host>|g" /opt/appdynamics/machine-agent/conf/controller-info.xml
sed -i "s|<controller-port>80</controller-port>|<controller-port>443</controller-port>|g" /opt/appdynamics/machine-agent/conf/controller-info.xml
sed -i "s|<controller-ssl-enabled>false</controller-ssl-enabled>|<controller-ssl-enabled>true</controller-ssl-enabled>|g" /opt/appdynamics/machine-agent/conf/controller-info.xml
#sed -i "s|<application-name></application-name>|<application-name>JDStoreAWSNonProd</application-name>|g" /opt/appdynamics/machine-agent/conf/controller-info.xml
sed -i "s|<account-name>Deere</account-name>|<account-name>deere-nonprod</account-name>|g" /opt/appdynamics/machine-agent/conf/controller-info.xml
sed -i "s|<account-access-key>dfa486b5-d943-48c8-81f4-6e737fe70e04</account-access-key>|<account-access-key>${appdaccess_key}</account-access-key>|g" /opt/appdynamics/machine-agent/conf/controller-info.xml

PRIVATEDNS="ip-${PRIVATEIP}.ec2.internal"
PRIVATEDNS=${PRIVATEDNS//./-}
NEWLINECHAR="\n"
if grep -xq "<unique-host-id>${PRIVATEDNS}</unique-host-id>" /opt/appdynamics/machine-agent/conf/controller-info.xml; then
  echo "No replacement done for <unique-host-id>"
else
   echo "Replaced <unique-host-id>"
  sed -i "s|</controller-info>|<unique-host-id>${PRIVATEDNS}</unique-host-id>${NEWLINECHAR}</controller-info>|g" /opt/appdynamics/machine-agent/conf/controller-info.xml
fi

echo " --------------------Configuring AppDynamics End --------------------"

service hybrisPlatform stop
service hybrisPlatform start

sleep 5m

echo "#########################################"
echo "# Ending application_start.sh           #"
echo "#########################################"
