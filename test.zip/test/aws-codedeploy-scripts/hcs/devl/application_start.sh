#!/bin/bash

DEPLOY_LOG="/var/log/hcs-codedeploy.log"
exec &>> $DEPLOY_LOG
echo "#########################################"
echo "# Running application_start.sh          #"
echo "#########################################"

service hybrisPlatform start

echo "#########################################"
echo "# Ending application_start.sh           #"
echo "#########################################"
