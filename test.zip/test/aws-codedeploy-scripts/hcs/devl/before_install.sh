#!/bin/bash

DEPLOY_LOG="/var/log/hcs-codedeploy.log"
exec &>> $DEPLOY_LOG

echo "#########################################"
echo "# Running before_install.sh             #"
echo "#########################################"

echo "#########################################"
echo "# Jenkins Parameters added              #"

ARTIFACT=$ARTIFACT
rm -rf /tmp/*
#rm -rf /tmp/hybrisServer*
#rm -rf /tmp/devl-opt_config.zip
echo "# End of Jenkins Parameters             #"
echo "#########################################"

#cd /tmp > /tmp/sim.log
#rm /tmp/application_stop.sh >> /tmp/sim.log
#rm /tmp/before_install.sh >> /tmp/sim.log
#rm /tmp/after_install.sh >> /tmp/sim.log
#rm -rf /tmp/${ARTIFACT} > /tmp/sim.log
#aws --region us-east-1 s3 cp s3://aws-parts-apps-devl-hcs/application_stop.sh . --sse AES256 >> /tmp/sim.log
#aws --region us-east-1 s3 cp s3://aws-parts-apps-devl-hcs/before_install.sh . --sse AES256 >> /tmp/sim.log
#aws --region us-east-1 s3 cp s3://aws-parts-apps-devl-hcs/after_install.sh . --sse AES256 >> /tmp/sim.log
#chmod +x application_stop.sh >> /tmp/sim.log
#chmod +x before_install.sh >> /tmp/sim.log
#chmod +x after_install.sh >> /tmp/sim.log
#./application_stop.sh >> /tmp/sim.log
#./before_install.sh >> /tmp/sim.log
#echo "Starting download of the Hybris Zip file...."
#aws --region us-east-1 s3 cp s3://aws-parts-apps-devl-hcs/deere-hybris-1.0-SNAPSHOT.zip /tmp/${ARTIFACT}/ --sse AES256 >> /tmp/sim.log
#echo "DONE downloading the Hybris Zip file."
#chown hcsuser:hcsgroup -R /tmp/${ARTIFACT} >> /tmp/sim.log
#chown hcsuser:hcsgroup /tmp/deere-hybris/deere-hybris-1.0-SNAPSHOT.zip >> /tmp/sim.log
#cd /tmp/${ARTIFACT} >> /tmp/sim.log
#aws --region us-east-1 s3 cp s3://aws-parts-apps-devl-hcs/installedSaplicenses.properties /www/hybrisCore/hybris/config/licence --sse AES256
#chown +x hcsuser:hcsgroup /www/hybrisCore/hybris/config/licence/installedSaplicenses.properties
#sudo su hcsuser

echo "#########################################"
echo "# Ending before_install.sh              #"
echo "#########################################"
