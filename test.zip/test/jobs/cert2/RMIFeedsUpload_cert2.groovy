freeStyleJob("hcs_57/RMIFeedsUpload-cert2") {
    description 'This jenkins job is used to copy all media from s3 to efs'
    logRotator(daysToKeep = -1, numToKeep = 10, artifactDaysToKeep = -1, artifactNumToKeep = -1)
    label('cert-slave')


    parameters {

      		stringParam("INSTANCEID", "", "Please enter the integration instance ID: i-0f290a79712ab1b65")
			fileParam('RmiFeeds.zip', 'my description')
    }

    wrappers {
      preBuildCleanup()
      maskPasswords()
    }

    steps {
        shell( '''
#!/bin/bash
set +x

   {
LOG_DIR=/var/lib/jenkins/workspace/hcs_57/Rmi-download-cert2

        mkdir -p $LOG_DIR/rmi
        mkdir -p $LOG_DIR/rmi/cronjob
        mkdir -p $LOG_DIR/rmi/hotfolder
        ls -l

		echo "copying the rmi files to integration folder"
        cd $LOG_DIR/rmi
        cp $LOG_DIR/RmiFeeds.zip $LOG_DIR/rmi
        unzip -o 'RmiFeeds.zip' < /dev/null
        pwd

        ls -l
        [ -f RMIModelJdFeed.csv ] && cp -rv RMIModelJdFeed.csv cronjob/ || echo "RMIModelJdFeed.csv does not exist"
        [ -f RMIPartsFitModel.csv ] && cp -rv RMIPartsFitModel.csv cronjob/ || echo "RMIPartsFitModel.csv does not exist"

        ls -l cronjob
        		echo "below files coping in hotfolder directory"
        [ -f productToCategory-*.csv ] &&  cp -rvf productToCategory-*.csv hotfolder/ || echo "productToCategory-01.csv does not exist"
        [ -f rmiproduct-*.csv ] &&  cp -rvf rmiproduct-*.csv hotfolder/ || echo "rmiproduct-01.csv does not exist"
        [ -f rmiCategory-*.csv ] && cp -rv rmiCategory-*.csv hotfolder/ || echo "rmiCategory-*.csv does not exist"

        rm -rf RmiFeeds.zip RMIModelJdFeed.csv RMIPartsFitModel.csv productToCategory-*.csv rmiproduct-*.csv rmiCategory-*.csv
 		ls -l hotfolder

        echo "uploading files in S3"
    	echo
        aws s3 sync /var/lib/jenkins/workspace/hcs_57/Rmi-download-cert2/rmi/ s3://aws-parts-ecommerce-cert2-hybrislogs/hcsintegrationbackup/jdb2c/rmi/ --delete --sse AES256
    	echo
        echo "downloading files from S3 to integration server"
        echo

     {
            COPY_INTEHRATION_FOLDER=("aws s3 --region us-east-1 cp s3://aws-parts-ecommerce-cert2-hybrislogs/hcsintegrationbackup/jdb2c/rmi/ /www/mounts/integration/jdb2c/rmi/ --recursive && chown -R hcsuser:hcsgroup /www/mounts/integration/jdb2c/rmi/ ")

			INTEHRATION_COMMAND="[\\"$COPY_INTEHRATION_FOLDER\\"]"

			echo $INSTANCEID
			if [ `echo "$INSTANCEID" ` ]; then
				 		    aws ssm send-command \\
                  					--document-name "AWS-RunShellScript" \\
                  					--targets Key=instanceids,Values=$INSTANCEID \\
                  					--parameters "{\\"commands\\":$INTEHRATION_COMMAND}" \\
                  					--region us-east-1

		    fi
             echo 'Rmi Files Uploaded successfully.'

			}

 	 }

        ''')
    }
}
