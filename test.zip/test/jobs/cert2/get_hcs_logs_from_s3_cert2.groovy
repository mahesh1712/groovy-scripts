
freeStyleJob('hcs_57/get-hcs-logs-from-s3-cert2') {
    logRotator(numToKeep = 100)
    label('cert-slave')
    wrappers {
        preBuildCleanup()
    }
    parameters {
        choiceParam("application", ["hcs","solr"])
        stringParam('instance_ip','' , "Give the IP address of the instance. example: instance=10.213.198.100")
        stringParam('file_name','' , "Give the log file name. example: console-20200128.log")
    }

    steps {
        shell( '''#!/bin/bash
set +x

echo "##################START LISTING FROM S3 BUCKET ############################"

aws --region us-east-1 s3 ls s3://aws-parts-ecommerce-cert2-hybrislogs/${application}/instance=${instance_ip}/applicationlogs/${file_name} --recursive

echo "##################END LISTING FROM S3 BUCKET ##############################"

echo "################## START TO GETLOGFILE FROM S3 BUCKET ############################"

aws --region us-east-1 s3 cp s3://aws-parts-ecommerce-cert2-hybrislogs/${application}/instance=${instance_ip}/applicationlogs/${file_name} ${file_name}

echo "##################END GETLOGFILE FROM S3 BUCKET ############################"

echo "################## START PRINTING DESTINATION FILE ############################"

cat ${file_name}

echo "##################END PRINTING DESTINATION FILE ############################"
set -x

        ''')
    }
}
