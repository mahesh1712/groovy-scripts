listView('hcs_57/CERT2 JOBS') {
	    description("Jobs for Development Environment")
	    jobs {
	        regex(
	            '.*cert2'
	        )
	    }
	    columns {
	        status()
	        weather()
	        name()
	        lastSuccess()
	        lastFailure()
	        lastDuration()
	       buildButton()
	    }
	}
