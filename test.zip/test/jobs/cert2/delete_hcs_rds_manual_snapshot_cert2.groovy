freeStyleJob('hcs_57/delete-hcs-rds-manual-snapshot-cert2') {
    logRotator(numToKeep = 100)
    label('cert-slave')
    parameters {
        stringParam("HCS_RDS_CLUSTER_ID", "hcs-rds-stack-cert2-hcsrdscert2rdscluster-9aofyu3t4c6f", "HCS RDS Cluster Identifier for Source DB")
        stringParam("ACCOUNT_NUMBER", "122749220977", "AWS Account Number")
        stringParam("ACCOUNT_ALIAS", "aws-parts-ecommerce")
        stringParam("ENVIRONMENT", "cert2")
        stringParam("ROLE_NAME", "jenkins/appslave-jenkins-partsecommerceapps")
     }
    triggers {
       cron('0 3 * * *')
    }
    steps {
        //Please keep indentation as shown below to avoid issues in the script.
        shell('''#!/bin/bash
aws rds describe-db-cluster-snapshots --db-cluster-identifier $HCS_RDS_CLUSTER_ID --snapshot-type manual --query 'DBClusterSnapshots[0:-7].[DBClusterSnapshotIdentifier]' --output text --no-paginate --region us-east-1 |
while read line;
do aws rds delete-db-cluster-snapshot --db-cluster-snapshot-identifier $line --region us-east-1;
done
        ''')

    }
}
