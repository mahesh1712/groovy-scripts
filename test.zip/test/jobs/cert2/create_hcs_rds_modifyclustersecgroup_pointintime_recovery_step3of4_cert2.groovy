freeStyleJob('hcs_57/create-hcs-rds-modifyclustersecgroup-pointintime-recovery-step3of4-cert2') {
    logRotator(numToKeep = 100)
    label('cert-slave')
    parameters {
        stringParam("TARGET_HCS_RDS_CLUSTER_ID", "", "HCS RDS Cluster Identifier for Target DB")
        stringParam("TARGET_SECURITY_GROUP_ID", "", "HCS RDS Security Group ID. Use SG of the source DB if used for point in time recovery.")
     }
     steps {
         //Please keep indentation as shown below to avoid issues in the script.
         shell('''#!/bin/bash
# Aurora MYSQL cluster point in time recovery
#run below command after creating cluster and DB instances using separate Jenkins job.
aws rds modify-db-cluster --db-cluster-identifier ${TARGET_HCS_RDS_CLUSTER_ID}  \
--vpc-security-group-ids ${TARGET_SECURITY_GROUP_ID} --region us-east-1
         ''')

     }
 }
