
freeStyleJob("hcs_57/copy-all-media-to-efs-cert2") {
    description 'This jenkins job is used to copy all media from s3 to efs'
    logRotator(daysToKeep = -1, numToKeep = 10, artifactDaysToKeep = -1, artifactNumToKeep = -1)
    label('cert-slave')


    parameters {
            
      		stringParam("BUCKET_NAME", "aws-parts-ecommerce-cert2-hybrislogs", "Please enter the bucket name.")
			stringParam("INSTANCEID", "", "Please enter the integration instance ID.")

    }

    wrappers {
      preBuildCleanup()
      maskPasswords()
    }
    steps {
        shell('''#!/bin/bash
    set -e

    function copy_efs_media {
            
            COPY_DESIGNER_FOLDER=("aws s3 --region us-east-1 cp s3://${BUCKET_NAME}/hcsdesignerbackup /www/mounts/designer/ --recursive && chown -R hcsuser:hcsgroup /www/mounts/designer/* ")
			COPY_INTEHRATION_FOLDER=("aws s3 --region us-east-1 cp s3://${BUCKET_NAME}/hcsintegrationbackup /www/mounts/integration/ --recursive && chown -R hcsuser:hcsgroup /www/mounts/integration/* ")
			COPY_MEDIA_FOLDER=("aws s3 --region us-east-1 cp s3://${BUCKET_NAME}/hcsmediabackup /www/mounts/media/ --recursive && chown -R hcsuser:hcsgroup /www/mounts/media/* ")   
            DESIGNER_COMMAND="[\"$COPY_DESIGNER_FOLDER\",""\"$ADD_LOG_ENTRY\"]"
			INTEHRATION_COMMAND="[\"$COPY_INTEHRATION_FOLDER\",""\"$ADD_LOG_ENTRY\"]"
			MEDIA_COMMAND="[\"$COPY_MEDIA_FOLDER\",""\"$ADD_LOG_ENTRY\"]"
			echo $DESIGNER_COMMAND
			if [ `echo "$INSTANCEID" ` ]; then
			

					aws ssm send-command \
                      --document-name "AWS-RunShellScript" \
                      --targets "Key=instanceids,Values=$INSTANCEID" \
                      --parameters "{\"commands\":$DESIGNER_COMMAND}" \
                      --region us-east-1
					
					aws ssm send-command \
                      --document-name "AWS-RunShellScript" \
                      --targets "Key=instanceids,Values=$INSTANCEID" \
                      --parameters "{\"commands\":$INTEHRATION_COMMAND}" \
                      --region us-east-1
					aws ssm send-command \
                      --document-name "AWS-RunShellScript" \
                      --targets "Key=instanceids,Values=$INSTANCEID" \
                      --parameters "{\"commands\":$MEDIA_COMMAND}" \
                      --region us-east-1
            fi
    }

    copy_efs_media $INSTANCEID

    echo 'Media Copied successfully.'

		''')
   }
}
