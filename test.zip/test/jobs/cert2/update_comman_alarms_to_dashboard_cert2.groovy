freeStyleJob("hcs_57/update-comman-alarm-to-dashboard-cert2") {
    description 'update comman alarms to custom cloudwatch dashboard'
    logRotator(daysToKeep = -1, numToKeep = 10, artifactDaysToKeep = -1, artifactNumToKeep = -1)
    label('cert-slave')

    wrappers {
      preBuildCleanup()
      maskPasswords()
    }
    steps {
        shell('''#!/bin/bash
set -e

sudo wget https://github.com/stedolan/jq/releases/download/jq-1.6/jq-linux64 -O jq
sudo chmod +x jq
sudo mv jq /usr/local/bin


dashboard_name="custom-dashboard"
region=$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document | grep -oP '(?<="region" : ")[^"]*(?=")')
remmoveAlarms=( 'hcscert2-MemoryAlarmHighASG' 'hcscert2-CPUAlarmHighASG' 'hcscert2-ActiveConnectionCount' 'hcscert2-UnhealthyHost' 'hcicert2-MemoryAlarmHighASG' 'hcicert2-CPUAlarmHighASG' 'hcicert2-EstimatedALBActiveConnectionCount' 'hcicert2-UnhealthyHost' 'hcsbocert2-ActiveConnectionCount' 'hcsbocert2-UnhealthyHost' 'hcsbocert2-CPUAlarmHigh' 'hcsbocert2-MemoryAlarmHigh' 'hcssolrcert2-MASTERMemoryAlarmHigh' 'hcssolrcert2-MASTERCPUAlarmHigh' 'hcssolrcert2-SLAVE1MemoryAlarmHigh' 'hcssolrcert2-SLAVE1CPUAlarmHigh' 'hcicert2-EstimatedALBActiveConnectionCount' 'hcssolrcert2-SLAVE2MemoryAlarmHigh' 'hcssolrcert2-SLAVE2CPUAlarmHigh' )

addAlarms=( 'hcscert2-MemoryAlarmHighASG' 'hcscert2-CPUAlarmHighASG' 'hcscert2-ActiveConnectionCount' 'hcscert2-UnhealthyHost' 'hcicert2-MemoryAlarmHighASG' 'hcicert2-CPUAlarmHighASG' 'hcicert2-EstimatedALBActiveConnectionCount' 'hcicert2-UnhealthyHost' 'hcsbocert2-ActiveConnectionCount' 'hcsbocert2-UnhealthyHost' 'hcsbocert2-CPUAlarmHigh' 'hcsbocert2-MemoryAlarmHigh' 'hcssolrcert2-MASTERMemoryAlarmHigh' 'hcssolrcert2-MASTERCPUAlarmHigh' 'hcssolrcert2-SLAVE1MemoryAlarmHigh' 'hcssolrcert2-SLAVE1CPUAlarmHigh' 'hcicert2-EstimatedALBActiveConnectionCount' 'hcssolrcert2-SLAVE2MemoryAlarmHigh' 'hcssolrcert2-SLAVE2CPUAlarmHigh' )
del_dash=$(aws cloudwatch get-dashboard --dashboard-name $dashboard_name --region "$region")
del_widgets=$(echo $del_dash | /usr/local/bin/jq -r '.DashboardBody')
for ALARMNAMES in "${remmoveAlarms[@]}";
do
        data=$(echo $del_widgets | /usr/local/bin/jq --arg ALARMNAME "$ALARMNAMES" 'del(.widgets[] | select(.properties.title | contains($ALARMNAME)))')
        del_widgets=$data
done

final_del_widgets=$(echo $del_widgets | /usr/local/bin/jq 'del(.widgets[].properties.type)')
del_DashboardBody=$final_del_widgets
aws cloudwatch --region "$region" put-dashboard --dashboard-name  $dashboard_name --dashboard-body "$del_DashboardBody"


add_dash=$(aws cloudwatch get-dashboard --dashboard-name $dashboard_name --region "$region")
add_widgets=$(echo $add_dash | /usr/local/bin/jq -r '.DashboardBody')

tmp_widgets=""
for alarm_name in "${addAlarms[@]}"
do
    echo $alarm_name
    alarm_arn=$(aws cloudwatch --region "$region" describe-alarms --alarm-names "$alarm_name" --query 'MetricAlarms[0].AlarmArn')
    new_widget='[{"type":"metric","properties":{"title":"'$alarm_name'","annotations":{"alarms":['$alarm_arn']},"region":"'$region'"}}]'
    tmp_widgets=$(echo $add_widgets | /usr/local/bin/jq --argjson w "$new_widget" '.widgets += $w')
    add_widgets=${tmp_widgets}
done
final_add_widgets=$(echo $add_widgets | /usr/local/bin/jq 'del(.widgets[].properties.type)')

add_DashboardBody=$final_add_widgets
aws cloudwatch --region "$region" put-dashboard --dashboard-name  $dashboard_name --dashboard-body "$add_DashboardBody"

            ''')
    }
}
