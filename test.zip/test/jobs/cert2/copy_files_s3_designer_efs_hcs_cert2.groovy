
freeStyleJob("hcs_57/copy-files-s3-designer-efs-hcs-cert2") {
    description 'Deploys app to a given account'
    logRotator(daysToKeep = -1, numToKeep = 10, artifactDaysToKeep = -1, artifactNumToKeep = -1)
    label('cert-slave')


    parameters {
            choiceParam("OPERATION", ["copy"])
      		  stringParam('INSTANCEID', ' ', 'Copy HCS Instance ID From AWS Console, Paste Here and Hit Build and if you want to use multiple instance Ids for copy files use (,) in between e.g. :- i-0de3b850e4ddec3232,i-0de3b850e4ddec2121' )
            stringParam('SOURCE_PATH', ' ', 'Copy whichever files from S3-designer folder to EFS-designer Paste Here and Hit Build and for multiple copy files use (,) in between e.g. :- test.png,jdstore.png' )

    }

    wrappers {
      preBuildCleanup()
      maskPasswords()
    }
    steps {
        shell('''#!/bin/bash
        set -e

        function sendCommand {

      	for i in $(echo $SOURCE_PATH | sed "s/,/ /g")
    	do

      			local COPY_FILES=("aws --region us-east-1 s3 cp s3://aws-parts-ecommerce-cert2-hcsdesigner/$i /www/mounts/designer/$i --recursive && chown hcsuser:hcsgroup /www/mounts/designer/$i")
    				local COMMANDS=""

    				COMMANDS="[\"$COPY_FILES\",""\"$ADD_LOG_ENTRY\"]"

    				echo $COPY_FILES
                     if [ `echo "$INSTANCEID" ` ]; then
                        aws ssm send-command \\
                          --document-name "AWS-RunShellScript" \\
                          --targets "Key=instanceids,Values=$INSTANCEID" \\
                          --parameters "{\"commands\":$COMMANDS,\"executionTimeout\":[\"3600\"]}" \\
                          --timeout-seconds 600 --region us-east-1 \\
                          --region us-east-1

                	fi
     done

        }

        sendCommand $INSTANCEID

        echo 'Copied files from S3 to EFS completed.'
		''')
   }
}
