freeStyleJob('hcs_57/delete-hcs-rds-manual-snapshot-prod') {
    logRotator(numToKeep = 100)
    label('prod-slave')
    parameters {
        stringParam("HCS_RDS_CLUSTER_ID", "hcs-rds-stack-hcsrdsrdscluster-1qkejp6ymh6cc", "HCS RDS Cluster Identifier for Source DB")
        stringParam("ACCOUNT_NUMBER", "728985623165", "AWS Account Number")
        stringParam("ACCOUNT_ALIAS", "aws-parts-ecommerce")
        stringParam("ENVIRONMENT", "prod")
        stringParam("ROLE_NAME", "jenkins/appslave-jenkins-partsecommerceapps")
     }
    triggers {
       cron('0 3 * * *')
    }
    steps {
        //Please keep indentation as shown below to avoid issues in the script.
        shell('''#!/bin/bash
aws rds describe-db-cluster-snapshots --db-cluster-identifier $HCS_RDS_CLUSTER_ID --snapshot-type manual --query 'DBClusterSnapshots[0:-7].[DBClusterSnapshotIdentifier]' --output text --no-paginate --region us-east-1 |
while read line;
do aws rds delete-db-cluster-snapshot --db-cluster-snapshot-identifier $line --region us-east-1;
done
        ''')

    }
}
