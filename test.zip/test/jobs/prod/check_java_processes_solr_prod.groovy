branch = "master"
git_url = "https://github.deere.com/ECommerce/ecommerce-hcs-infra"


freeStyleJob("hcs_57/check-java-processes-solr-prod") {
    description 'Checks java pids running on the instance'
    logRotator(daysToKeep = -1, numToKeep = 10, artifactDaysToKeep = -1, artifactNumToKeep = -1)
    label('prod-slave')

    parameters {
            choiceParam("NODE_GROUP", ["master","slave1","slave2","slave3","master,slave1,slave2,slave3"])

    }

    wrappers {
      preBuildCleanup()
      maskPasswords()
    }
    steps {
        shell('''#!/bin/bash
set -e

TAG_NAME_MASTER=hcssolrMASTER-EC2
TAG_NAME_SLAVE1=hcssolrSLAVE1-EC2
TAG_NAME_SLAVE2=hcssolrSLAVE2-EC2
TAG_NAME_SLAVE3=hcssolrSLAVE3-EC2


function sendCommand {


        local TAG_VALUES="[\\"$1\\"]"

        local COMMANDS="[\\"ps -ef | grep java\\"]"


        echo Destination: $TAG_VALUES
        echo $COMMANDS
        echo "{\\"Key\\":\\"tag:component\\",\\"Values\\":$TAG_VALUES}"


        if [ ! "$NODE_GROUP" == " " ] ; then
            sh_command_id=$(aws ssm send-command \\
                  --document-name "AWS-RunShellScript" \\
                  --targets Key=tag:Name,Values=$TAG_VALUES \\
                  --parameters "{\\"commands\\":$COMMANDS,\\"executionTimeout\\":[\\"3600\\"]}" \\
                  --timeout-seconds 600  \\
                  --region us-east-1  --output text --query "Command.CommandId")
            echo $sh_command_id
            echo 'waiting for response..'
            sleep 8
            aws ssm list-command-invocations --region us-east-1 --command-id $sh_command_id --details  --query "[CommandInvocations[].CommandPlugins[].{Status:Status,Output:Output}, CommandInvocations[].{InstanceId:InstanceId}]"
        else
            echo "Please provide values for NODE_GROUP ."

        fi
}

if [ `echo "$NODE_GROUP" | grep 'master'` ]; then
        sendCommand $TAG_NAME_MASTER
fi

if [ `echo "$NODE_GROUP" | grep 'slave1'` ]; then
        sendCommand $TAG_NAME_SLAVE1
fi

if [ `echo "$NODE_GROUP" | grep 'slave2'` ]; then
        sendCommand $TAG_NAME_SLAVE2
fi

if [ `echo "$NODE_GROUP" | grep 'slave3'` ]; then
        sendCommand $TAG_NAME_SLAVE3
fi

echo 'Job completed.'

            ''')
    }
}
