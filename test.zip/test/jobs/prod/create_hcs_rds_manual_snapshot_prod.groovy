freeStyleJob('hcs_57/create-hcs-rds-manual-snapshot-prod') {
    logRotator(numToKeep = 100)
    label('prod-slave')
    parameters {
        stringParam("HCS_RDS_CLUSTER_ID", "hcs-rds-stack-hcsrdsrdscluster-1qkejp6ymh6cc", "HCS RDS Cluster Identifier for Source DB")
        stringParam("ACCOUNT_NUMBER", "728985623165", "AWS Account Number")
        stringParam("ACCOUNT_ALIAS", "aws-parts-ecommerce")
        stringParam("ENVIRONMENT", "prod")
        stringParam("ROLE_NAME", "jenkins/appslave-jenkins-partsecommerceapps")
     }
    triggers {
        cron('0 2 * * *')
    }
    steps {
        //Please keep indentation as shown below to avoid issues in the script.
        shell('''#!/bin/bash
timestamp=$(date +"%Y-%m-%d-%H-%M-%S")
HCS_RDS_SNAPSHOT_NAME=${HCS_RDS_CLUSTER_ID}-manual-snapshot-$timestamp
echo $HCS_RDS_SNAPSHOT_NAME
aws rds create-db-cluster-snapshot --db-cluster-identifier ${HCS_RDS_CLUSTER_ID} --db-cluster-snapshot-identifier ${HCS_RDS_SNAPSHOT_NAME} --region us-east-1 --tags Key=Name,Value=hcsrdssnapshot Key=component,Value=hybris
        ''')

    }
}
