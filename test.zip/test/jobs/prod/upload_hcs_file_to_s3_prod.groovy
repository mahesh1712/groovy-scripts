
freeStyleJob('hcs_57/upload_hcs_file_to_s3_prod') {
    logRotator(numToKeep = 100)
    label('prod-slave')
    wrappers {
        preBuildCleanup()
    }
    parameters {
        fileParam('installedSaplicenses.properties', "Choose the Source path here")
        fileParam('change-resource-record-sets.json', "Choose the Source path here")
        fileParam('rds-ca-2019-root.pem', "Choose the Source path here")
    }

    steps {
        shell( '''
#!/bin/bash


################## UNCOMMENT LINES BELOW TO UPLOAD TO S3 BUCKET ############################
if [ -f installedSaplicenses.properties ]; then
  aws --region us-east-1 s3 cp installedSaplicenses.properties s3://aws-parts-ecommerce-prod-hcs/hybris_license/ --sse AES256
else
  echo "installedSaplicenses.properties file doesn't exist"
fi

if [ -f change-resource-record-sets.json ]; then
  aws --region us-east-1 s3 cp change-resource-record-sets.json s3://aws-parts-ecommerce-prod-hcs/scripts/solr/ --sse AES256
else
  echo "change-resource-record-sets.json file doesn't exist"
fi
if [ -f rds-ca-2019-root.pem ]; then
  aws --region us-east-1 s3 cp rds-ca-2019-root.pem s3://aws-parts-ecommerce-prod-hcs/rds/ssl_public_key/ --sse AES256
else
  echo "rds-ca-2019-root.pem file doesn't exist"
fi

##################END UNCOMMENT LINES BELOW TO CREATE KEY PAIR ############################

##################START UNCOMMENT LINES BELOW TO DELETE FROM S3 BUCKET ############################
#aws --region us-east-1 s3 rm s3://${BUCKET_NAME}/ --recursive
##################END UNCOMMENT LINES BELOW TO DELETE KEY PAIR ############################
        ''')
    }
}
