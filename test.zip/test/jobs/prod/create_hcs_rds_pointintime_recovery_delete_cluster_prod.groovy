freeStyleJob('hcs_57/create-hcs-rds-pointintime-recovery-delete-cluster-prod') {
    logRotator(numToKeep = 100)
    label('prod-slave')
    parameters {
        stringParam("HCS_RDS_CLUSTER_ID", "", "HCS RDS  Cluster Identifier to be deleted")
        stringParam("HCS_RDS_CLUSTER_FINAL_SNAPSHOTNAME", "", "HCS RDS  Cluster final Snapshot to be created before deletion")
     }
     steps {
         //Please keep indentation as shown below to avoid issues in the script.
         shell('''#!/bin/bash
  # Aurora MYSQL cluster point in time recovery- delete cluster after testing. Note: Instances should be deleted first.
  aws rds delete-db-cluster --db-cluster-identifier ${HCS_RDS_CLUSTER_ID} \
  --skip-final-snapshot --region us-east-1
  #--final-db-snapshot-identifier ${HCS_RDS_CLUSTER_FINAL_SNAPSHOTNAME} --region us-east-1
         ''')
     }
 }
