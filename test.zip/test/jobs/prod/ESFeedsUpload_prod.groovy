freeStyleJob("hcs_57/ESFeedsUpload-prod") {
    description 'This jenkins job is used to copy all media from s3 to efs'
    logRotator(daysToKeep = -1, numToKeep = 10, artifactDaysToKeep = -1, artifactNumToKeep = -1)
    label('prod-slave')

    parameters {

      		stringParam("INSTANCEID", "", "Please enter the integration instance ID: i-0f290a79712ab1b65")
			fileParam('ESFeeds.zip', 'my description')
    }

    wrappers {
      preBuildCleanup()
      maskPasswords()
    }

    steps {
        shell( '''#!/bin/bash
set +x
   {
		LOG_DIR=$WORKSPACE

        mkdir -p $LOG_DIR/employeestore
        mkdir -p $LOG_DIR/employeestore/hotfolder
		mkdir -p $LOG_DIR/employeestore/hotfolder/processing
        ls -l

		echo "copying the es files to integration folder"
        #cd $LOG_DIR/employeestore
#        cp $LOG_DIR/ESFeeds.zip $LOG_DIR/employeestore
        unzip -o 'ESFeeds.zip' < /dev/null
        pwd
		
        echo "below files coping in hotfolder directory"
		files=( employeeStoreProduct-*.csv )
		if (( ${#files[@]} )); then
			cp -rvf employeeStoreProduct-*.csv $LOG_DIR/employeestore/hotfolder/
		else
		echo "employeeStoreProduct-*.csv does not exist"
		fi

		filesone=( employeeStoreCategory-*.csv )
		if (( ${#filesone[@]} )); then
			cp -rvf employeeStoreCategory-*.csv $LOG_DIR/employeestore/hotfolder/
		else
		echo "employeeStoreCategory-*.csv does not exist"
		fi


		filestwo=( employeeStoreProductToCategory-*.csv )
		if (( ${#filestwo[@]} )); then
			cp -rvf employeeStoreProductToCategory-*.csv $LOG_DIR/employeestore/hotfolder/
		else
		echo "employeeStoreProductToCategory-*.csv does not exist"
		fi

		filesthree=( employeeProductToAvailabilityAssignment-*.csv )
		if (( ${#filesthree[@]} )); then
			cp -rvf employeeProductToAvailabilityAssignment-*.csv $LOG_DIR/employeestore/hotfolder/
		else
		echo "employeeProductToAvailabilityAssignment-*.csv does not exist"
		fi

		filesfour=( employeeStoreprice-*.csv )
		if (( ${#filesfour[@]} )); then
			cp -rvf employeeStoreprice-*.csv $LOG_DIR/employeestore/hotfolder/
		else
		echo "employeeStoreprice-*.csv does not exist"
		fi

		echo "uploading files in S3"
        aws s3 sync $WORKSPACE/employeestore/hotfolder/ s3://aws-parts-ecommerce-prod-hybrislogs/hcsintegrationbackup/jdb2c/employeestore/hotfolder/ --delete --sse AES256

		{

			COMMANDS="[\\"aws s3 --region us-east-1 cp s3://aws-parts-ecommerce-prod-hybrislogs/hcsintegrationbackup/jdb2c/employeestore/hotfolder  /www/mounts/integration/jdb2c/employeestore/hotfolder/ --recursive --sse AES256 && chown -R hcsuser:hcsgroup /www/mounts/integration/jdb2c/employeestore/ \\"]"
			echo $INSTANCEID
			if [ `echo "$INSTANCEID" ` ]; then

			sh_command_id=$(aws ssm send-command \
                  --document-name "AWS-RunShellScript" \
                  --targets Key=instanceids,Values=$INSTANCEID \
                  --parameters "{\\"commands\\":$COMMANDS,\\"executionTimeout\\":[\\"7200\\"]}" \
                  --timeout-seconds 600  \
                  --region us-east-1  --output text --query "Command.CommandId")
            echo $sh_command_id


		    fi
             echo 'ES Files Uploaded successfully.'

		}

 	}

    ''')
    }
}
