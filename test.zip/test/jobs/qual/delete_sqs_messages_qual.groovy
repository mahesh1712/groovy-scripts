
freeStyleJob('hcs_57/delete-sqs-all-messages-qual') {
    logRotator(numToKeep = 10)
    label('qual-slave')
    wrappers {
        preBuildCleanup()
    }
    parameters {
        choiceParam("QUELE_NAME", ["hcsdesignerqueue"], "Please select the queue name to delete the message")
    }

    steps {
        shell( '''
#!/bin/bash

echo "##################START DELETING SQS MESSAGES ############################"

SQS_URL=$(aws sqs get-queue-url --queue-name=$QUELE_NAME --output text --region us-east-1)
aws sqs purge-queue --queue-url $SQS_URL --region us-east-1

echo "##################END DELETING SQS MESSAGES ############################"

        ''')
    }
}
