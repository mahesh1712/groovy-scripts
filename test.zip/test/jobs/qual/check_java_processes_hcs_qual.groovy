branch = "master"
git_url = "https://github.deere.com/ECommerce/ecommerce-hcs-infra"


freeStyleJob("hcs_57/check-java-processes-hcs-qual") {
    description 'Checks java pids running on the instance'
    logRotator(daysToKeep = -1, numToKeep = 10, artifactDaysToKeep = -1, artifactNumToKeep = -1)
    label('qual-slave')
    parameters {
            choiceParam("NODE_GROUP", ["backoffice","storefront","backoffice,storefront"])
            stringParam('INSTANCEID', ' ', 'Copy HCS Instance ID From AWS Console, Paste Here. Only provide one instance id' )

    }

    wrappers {
      preBuildCleanup()
      maskPasswords()
    }
    steps {
        shell('''#!/bin/bash
set -e

TAG_NAME_STOREFRONT=hcs-EC2
TAG_NAME_BACKOFFICE=hcsbo-EC2


function sendCommand {


        local TAG_VALUES="[\\"$1\\"]"
        local COMMANDS="[\\"ps -ef | grep java\\"]"

        echo Destination: $TAG_VALUES
        echo $COMMANDS
        echo "{\\"Key\\":\\"tag:component\\",\\"Values\\":$TAG_VALUES}"


        if [[ ! "$INSTANCEID" == " "  &&  ! "$NODE_GROUP" == " " ]] ; then
            sh_command_id=$(aws ssm send-command \\
                  --document-name "AWS-RunShellScript" \\
                  --targets "Key=instanceids,Values=$INSTANCEID" \\
                  --parameters "{\\"commands\\":$COMMANDS,\\"executionTimeout\\":[\\"3600\\"]}" \\
                  --timeout-seconds 600 --region us-east-1 \\
                  --region us-east-1 \
                  --output text --query "Command.CommandId")
            echo 'waiting for response..'
            sleep 5
            aws ssm list-command-invocations --region us-east-1 --command-id $sh_command_id --details --query "[CommandInvocations[].CommandPlugins[].{Status:Status,Output:Output}, CommandInvocations[].{InstanceId:InstanceId}]"
        elif [ ! "$NODE_GROUP" == " " ] ; then
            sh_command_id=$(aws ssm send-command \\
                  --document-name "AWS-RunShellScript" \\
                  --targets Key=tag:Name,Values=$TAG_VALUES \\
                  --parameters "{\\"commands\\":$COMMANDS,\\"executionTimeout\\":[\\"3600\\"]}" \\
                  --timeout-seconds 600  \\
                  --region us-east-1  --output text --query "Command.CommandId")
            echo $sh_command_id
            echo 'waiting for response..'
            sleep 5
            aws ssm list-command-invocations --region us-east-1 --command-id $sh_command_id --details  --query "[CommandInvocations[].CommandPlugins[].{Status:Status,Output:Output}, CommandInvocations[].{InstanceId:InstanceId}]"
        else
            echo "Please provide values for INSTANCEID and/or NODE_GROUP ."

        fi
}

if [ `echo "$NODE_GROUP" | grep 'backoffice'` ]; then
        sendCommand $TAG_NAME_BACKOFFICE $INSTANCEID
fi
if [ `echo "$NODE_GROUP" | grep 'storefront'` ]; then
        sendCommand $TAG_NAME_STOREFRONT $INSTANCEID
fi

echo 'Job completed.'

            ''')
    }
}
