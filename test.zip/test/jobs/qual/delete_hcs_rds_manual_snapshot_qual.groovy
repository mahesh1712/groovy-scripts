freeStyleJob('hcs_57/delete-hcs-rds-manual-snapshot-qual') {
    logRotator(numToKeep = 100)
    label('qual-slave')
    parameters {
        stringParam("HCS_RDS_CLUSTER_ID", "hcs-rds-stack-hcsrdsrdscluster-1pvdg26j72xfk", "HCS RDS Cluster Identifier for Source DB")
        stringParam("ACCOUNT_NUMBER", "446144384807", "AWS Account Number")
        stringParam("ACCOUNT_ALIAS", "aws-parts-ecommerce")
        stringParam("ENVIRONMENT", "qual")
        stringParam("ROLE_NAME", "jenkins/appslave-jenkins-partsecommerceapps")
     }
    triggers {
       cron('0 3 * * *')
    }
    steps {
        //Please keep indentation as shown below to avoid issues in the script.
        shell('''#!/bin/bash
aws rds describe-db-cluster-snapshots --db-cluster-identifier $HCS_RDS_CLUSTER_ID --snapshot-type manual --query 'DBClusterSnapshots[0:-4].[DBClusterSnapshotIdentifier]' --output text --no-paginate --region us-east-1 |
while read line;
do aws rds delete-db-cluster-snapshot --db-cluster-snapshot-identifier $line --region us-east-1;
done
        ''')

    }
}
