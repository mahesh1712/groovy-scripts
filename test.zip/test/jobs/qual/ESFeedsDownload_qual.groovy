freeStyleJob("hcs_57/ESFeedsDownload-qual") {
    description 'This jenkins job is used to copy all media from s3 to efs'
    logRotator(daysToKeep = -1, numToKeep = 10, artifactDaysToKeep = -1, artifactNumToKeep = -1)
    label('qual-slave')


    parameters {

      		stringParam("INSTANCEID", "", "Please enter the integration instance ID: i-0f290a79712ab1b65")
      		stringParam('file_name','' , "Give the log file name. example: hotfolder/employeeStoreProduct-1127.csv")

    }

    wrappers {
      preBuildCleanup()
      maskPasswords()
    }

    steps {
        shell( '''#!/bin/bash
set +x

    function copy_employeestore_efs {

			COMMANDS="[\\"aws s3 sync /www/mounts/integration/jdb2c/employeestore/ s3://aws-parts-ecommerce-qual-hybrislogs/hcsintegrationbackup/jdb2c/employeestore/ --delete --sse AES256 \\"]"


			echo $INSTANCEID
			if [ `echo "$INSTANCEID" ` ]; then
				sh_command_id=$(aws ssm send-command \
                  --document-name "AWS-RunShellScript" \
                  --targets Key=instanceids,Values=$INSTANCEID \
                  --parameters "{\\"commands\\":$COMMANDS,\\"executionTimeout\\":[\\"7200\\"]}" \
                  --timeout-seconds 600  \
                  --region us-east-1  --output text --query "Command.CommandId")
            echo $sh_command_id
		    fi
     }


    copy_employeestore_efs $INSTANCEID

	{

	LOG_DIR=$WORKSPACE


echo "################## START TO GETLOGFILE FROM S3 BUCKET ############################"

aws --region us-east-1 s3 cp s3://aws-parts-ecommerce-qual-hybrislogs/hcsintegrationbackup/jdb2c/employeestore/ $LOG_DIR --recursive --sse AES256 >>test.txt
pwd
ls -l

echo "hotfolder"
ls -l hotfolder



echo "##################END GETLOGFILE FROM S3 BUCKET ############################"

echo "################## START PRINTING DESTINATION FILE ############################"
echo
cat ${file_name}
echo
echo "##################END PRINTING DESTINATION FILE ############################"

echo 'ES Files Copied successfully.'

}
        ''')
    }
}
