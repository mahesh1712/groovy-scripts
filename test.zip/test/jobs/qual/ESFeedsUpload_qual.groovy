freeStyleJob("hcs_57/ESFeedsUpload-qual") {
    description 'This jenkins job is used to copy all media from s3 to efs'
    logRotator(daysToKeep = -1, numToKeep = 10, artifactDaysToKeep = -1, artifactNumToKeep = -1)
    label('qual-slave')


    parameters {

      		stringParam("INSTANCEID", "", "Please enter the integration instance ID: i-0f290a79712ab1b65")
			fileParam('ESFeeds.zip', 'my description')
    }

    wrappers {
      preBuildCleanup()
      maskPasswords()
    }

    steps {
        shell( '''#!/bin/bash
set +x
   {
		LOG_DIR=$WORKSPACE

        mkdir -p $LOG_DIR/employeestore
        mkdir -p $LOG_DIR/employeestore/hotfolder
		mkdir -p $LOG_DIR/employeestore/hotfolder/processing
        ls -l

		echo "copying the es files to integration folder"
        #cd $LOG_DIR/employeestore
#        cp $LOG_DIR/ESFeeds.zip $LOG_DIR/employeestore
        unzip -o 'ESFeeds.zip' < /dev/null
        pwd
		
        echo "below files coping in hotfolder directory"
        [ -f employeeStoreProduct-*.csv ] &&  cp -rvf employeeStoreProduct-*.csv $LOG_DIR/employeestore/hotfolder/ || echo "employeeStoreProduct-*.csv does not exist"
        [ -f employeeStoreCategory-*.csv ] &&  cp -rvf employeeStoreCategory-*.csv $LOG_DIR/employeestore/hotfolder/ || echo "employeeStoreCategory-*.csv does not exist"
        [ -f employeeStoreProductToCategory-*.csv ] && cp -rv employeeStoreProductToCategory-*.csv $LOG_DIR/employeestore/hotfolder/ || echo "employeeStoreProductToCategory-*.csv does not exist"
		[ -f employeeProductToAvailabilityAssignment-*.csv ] && cp -rv employeeProductToAvailabilityAssignment-*.csv $LOG_DIR/employeestore/hotfolder/ || echo "employeeProductToAvailabilityAssignment-*.csv does not exist"

		echo "uploading files in S3"
        aws s3 sync $WORKSPACE/hotfolder/ s3://aws-parts-ecommerce-qual-hybrislogs/hcsintegrationbackup/jdb2c/employeestore/hotfolder/ --delete --sse AES256

     {

			COMMANDS="[\\"aws s3 --region us-east-1 cp s3://aws-parts-ecommerce-qual-hybrislogs/hcsintegrationbackup/jdb2c/employeestore/hotfolder  /www/mounts/integration/jdb2c/employeestore/hotfolder/ --recursive --sse AES256 && chown -R hcsuser:hcsgroup /www/mounts/integration/jdb2c/employeestore/ \\"]"
			echo $INSTANCEID
			if [ `echo "$INSTANCEID" ` ]; then

			sh_command_id=$(aws ssm send-command \
                  --document-name "AWS-RunShellScript" \
                  --targets Key=instanceids,Values=$INSTANCEID \
                  --parameters "{\\"commands\\":$COMMANDS,\\"executionTimeout\\":[\\"7200\\"]}" \
                  --timeout-seconds 600  \
                  --region us-east-1  --output text --query "Command.CommandId")
            echo $sh_command_id


		    fi
             echo 'ES Files Uploaded successfully.'

			}

 	 }

        ''')
    }
}
