branch = "master"
git_url = "https://github.deere.com/ECommerce/ecommerce-hcs-infra"
pipelineJob('hcs_57/hcs-build-deploy-devl') {
	parameters {
		stringParam('HYBRIS_COMMERCE_SUITE','CXCOMM201100P_6-70005693.zip', "For 1811 Build =  CXCOMM181100P_16-70004085.ZIP     For 2011 Build =  CXCOMM201100P_6-70005693.zip")
        stringParam('HYBRIS_OPT_CONFIG_DIR','/var/lib/jenkins/workspace/hcs_57/hcs-build-deploy-devl/hybris/env/ci')	
		choiceParam("Stage", ["BuildOnly","DeployOnly","BuildAndDeployBoth"],"Select Stage")
		choiceParam("branch_name", ["master","develop","release-oct2021"],"Please select the branch name.")
		choiceParam("Dry_Run", ["No","Yes"],"Do you Want to DEBUG mode?")
		choiceParam("DEBUG", ["No","Yes"],"Do you Want to DEBUG mode?")
		choiceParam("VERACODE", ["Yes","No"],"Do you Want to perform Veracode Scan ? Note: If you are executing from master it will not skip")
		choiceParam("SonarQube", ["Yes","No"],"Do you Want to perform SonarQube Scan ? Note: If you are executing from master it will not skip")
		stringParam('DEPLOY_APPLICATION_NAME',"hcs-codedeploy-application",'Required: Code deploy application name associated with given code deployment group i.e., asset-api')
		stringParam('MYENV',"devl",'Environment')
		stringParam('BUCKET_NAME','aws-parts-ecommerce-devl-hcs','Required: S3 bucket for app aws package bundle i.e., aws-parts-apps-devl-hcs')
		choiceParam("SOLAR_DEPLOY", ["No","Yes"],"Please select Yes to start solar deployment.")

	}
    definition {
        cpsScm {
			scm {
				git {
					remote {
						url("${git_url}")
						credentials('hcs-infra-github-token')
					}
					branch("${branch}")
					extensions {
					}
				}
			}
			scriptPath('jobs/devl/hcs_build_deploypipeline_devl')
        }
    }
}