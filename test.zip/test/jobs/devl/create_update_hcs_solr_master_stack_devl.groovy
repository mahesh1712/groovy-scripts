branch = "master"
git_url = "https://github.deere.com/ECommerce/ecommerce-hcs-infra"

freeStyleJob('hcs_57/create-update-hcs-solr-master-stack-devl') {
    logRotator(numToKeep = 100)
    parameters {
        stringParam("ACCOUNT_NUMBER", "809731660233", "AWS Account Number")
        stringParam("ACCOUNT_ALIAS", "aws-parts-ecommerce")
        stringParam("ENVIRONMENT", "devl")
        stringParam("ROLE_NAME", "jenkins/appslave-jenkins-partsecommerceapps")
		stringParam("hcssolroldInstanceid", "","Please Enter the current instance id. ex:i-00b32f13fedb3f0e9")
        choiceParam("OPERATIONS", ["dry_run","deploy","delete"])
        choiceParam("RE_CREATE", ["false","true"])
    }
    scm {
	    git {
            remote {
                  url(git_url)
                  credentials('hcs-infra-github-token')
            }
            branch(branch)
        }
    }
    steps {
        shell( '''
#!/bin/bash
ARCH_FILE=aws-cloudformation/arch-yamls/arch-hcs-solr-master.j2
VAR_FILE=aws-cloudformation/config/$ACCOUNT_ALIAS-$ENVIRONMENT/hcs-solr.yml
STACK_NAME=hcs-solr-master-stack
CONFIG_FILE=aws-cloudformation/stack-params/$ACCOUNT_ALIAS-$ENVIRONMENT.config
TEMPLATE_URL=$ACCOUNT_ALIAS-$ENVIRONMENT-system/templates/hcs-solr-master-stack.json
ROLE_NAME=$ROLE_NAME


if [ "$RE_CREATE" = false ]
then
   FORCE_DELETE=""
else
   FORCE_DELETE=--force_delete
fi

python --version
python -m cloud_common.aws_stack_operation \\
--region us-east-1 \\
--role_name $ROLE_NAME \\
--account_number $ACCOUNT_NUMBER \\
--operation $OPERATIONS \\
--arch $ARCH_FILE \\
--var $VAR_FILE \\
--stack_name $STACK_NAME \\
--config_file $CONFIG_FILE \\
--template_url $TEMPLATE_URL \\
--log DEBUG $FORCE_DELETE $USE_EXISTING
        ''')
    }
}
