	freeStyleJob("hcs_57/hcs-57-hybris-install-media-test") {
	    description ' '
	    label('devl-slave')

	    parameters {

	      		fileParam('HYBRISCOMM6300P_7-70002554.zip', ' ')

	    }
	}
