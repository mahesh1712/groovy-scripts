freeStyleJob("hcs_57/create-typesystem_hcs_devl") {
    description 'Checks java pids running on the instance'
    logRotator(daysToKeep = -1, numToKeep = 5, artifactDaysToKeep = -1, artifactNumToKeep = -1)
    label('devl-slave')
    parameters {
            choiceParam("NODE_GROUP", ["backoffice"])
            stringParam('TYPESYSNAME', ' ', 'Please enter the type system name.' )

    }

    wrappers {
      preBuildCleanup()
      maskPasswords()
    }
    steps {
        shell('''#!/bin/bash
set -e

TAG_NAME_BACKOFFICE=hcsbo-EC2


function sendCommand {

		echo $1"==="$2
        local TAG_VALUES="[\\"$1\\"]"
		local TYPESYSNAME=$2
        local COMMANDS="[\\"aws s3 cp s3://aws-parts-ecommerce-devl-hcs/customscripts/typesystem/devl/typesystem.sh /tmp/typesystem.sh --region us-east-1 --sse AES256 && chmod +x /tmp/typesystem.sh && /tmp/typesystem.sh createtypesystem $TYPESYSNAME \\"]"
		local COPY_COMMANDS="[\\"aws s3 cp /tmp/createtypesystem.txt s3://aws-parts-ecommerce-devl-hcs/typesystem/createtypesystem.txt --region us-east-1 --sse AES256 && /tmp/typesystem.sh revertdbconfig \\"]"
        echo Destination: $TAG_VALUES
        echo $COMMANDS
        echo "{\\"Key\\":\\"tag:component\\",\\"Values\\":$TAG_VALUES}"

	if [[ ! "$TYPESYSNAME" == " "  &&  ! "$NODE_GROUP" == " " ]] ; then
            sh_command_id=$(aws ssm send-command \
                  --document-name "AWS-RunShellScript" \
                  --targets Key=tag:Name,Values=$TAG_VALUES \
                  --parameters "{\\"commands\\":$COMMANDS,\\"executionTimeout\\":[\\"7200\\"]}" \
                  --timeout-seconds 600  \
                  --region us-east-1  --output text --query "Command.CommandId")
            echo $sh_command_id
            
            echo 'waiting for response..'
			sleep 5m
            sh_command_id_copy=$(aws ssm send-command \
                  --document-name "AWS-RunShellScript" \
                  --targets Key=tag:Name,Values=$TAG_VALUES \
                  --parameters "{\\"commands\\":$COPY_COMMANDS,\\"executionTimeout\\":[\\"7200\\"]}" \
                  --timeout-seconds 600  \
                  --region us-east-1  --output text --query "Command.CommandId")
            echo $sh_command_id_copy

			sleep 1m
			LOG_DIR=/var/lib/jenkins/workspace/hcs_57/create-typesystem_hcs_devl/

			aws --region us-east-1 s3 cp s3://aws-parts-ecommerce-devl-hcs/typesystem/ $LOG_DIR --recursive --sse AES256
			cat ${LOG_DIR}/createtypesystem.txt
        else
            echo "Please provide values for INSTANCEID and/or NODE_GROUP."

        fi
}

if [ `echo "$NODE_GROUP" | grep 'backoffice'` ]; then
        sendCommand $TAG_NAME_BACKOFFICE $TYPESYSNAME
fi


echo 'Job completed.'

            ''')
    }
}
