freeStyleJob('hcs_57/create-hcs-rds-manual-failover-devl') {
    logRotator(numToKeep = 100)
    label('devl-slave')
    parameters {
        stringParam("HCS_RDS_CLUSTER_ID", "", "HCS RDS Cluster Identifier for Source DB")
     }
     steps {
         //Please keep indentation as shown below to avoid issues in the script.
         shell('''#!/bin/bash
 aws rds failover-db-cluster --db-cluster-identifier ${HCS_RDS_CLUSTER_ID} --region us-east-1         ''')
     }
 }
