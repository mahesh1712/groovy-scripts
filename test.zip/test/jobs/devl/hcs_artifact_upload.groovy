    freeStyleJob("hcs_57/hcs_artifact_upload") {
       logRotator(daysToKeep = -1, numToKeep = 15, artifactDaysToKeep = -1, artifactNumToKeep = -1)
        label('devl-slave')
    	parameters {
			choiceParam("deployment", ["1811","2011"],"Please select the option 1811=> To deploy 1811 codebase. 2011=> To deploy 2011 codebase.")
		}
        wrappers {
          preBuildCleanup()
          maskPasswords()
        }

        steps {
            shell('''
    cp ../hcs_57_build/deere-hybris.zip .
    cp ../hcs_57_build/hybris/temp/hybris/hybrisServer/deere-solr.tgz .
    	   ''')
        }

    	steps {
        shell('''#!/bin/bash
set -e
			artifactorypassword=$(aws ssm get-parameter --region us-east-1 --name hcsartifactpassword --with-decryption | grep Value | awk -F '"' '{print $4}')
if [ $deployment == "1811" ]
then
	VERSION="1.0-SNAPSHOT"
elif [ $deployment == "2011" ]
then
	VERSION="1.1-SNAPSHOT"
fi
  echo "===$VERSION==="
    echo "Uploading Hybris zip..."
    curl -X PUT -u adyhcjj:${artifactorypassword} -T deere-hybris.zip "https://repository.deere.com/artifactory/parts-hcs-snapshot-local/com/deere/parts/hcs/deere-hybris/$VERSION/deere-hybris-$VERSION.zip"

    echo "Uploading Solr zip..."
    curl -X PUT -u adyhcjj:${artifactorypassword} -T deere-solr.tgz "https://repository.deere.com/artifactory/parts-hcs-snapshot-local/com/deere/parts/hcs/deere-solr/$VERSION/deere-solr-$VERSION.tgz"

    	   ''')
        }
    }
