branch = "master"
git_url = "https://github.deere.com/ECommerce/ecommerce-hcs-infra"


freeStyleJob("hcs_57/deploy-hcs-apptest-devl") {
    description 'Deploys app to a given account'
    logRotator(daysToKeep = 365, numToKeep = -1, artifactDaysToKeep = -1, artifactNumToKeep = -1)

	scm {
        git {
            remote {
                url("${git_url}")
                credentials('hcs-infra-github-token')
            }
            branch("${branch}")
            extensions {
            }
        }

    }
    parameters {
            stringParam('DEPLOY_APPLICATION_NAME',"hcstest-codedeploy-application",'Required: Code deploy application name associated with given code deployment group i.e., asset-api')
            stringParam('MYENV',"devl",'Environment')
            stringParam('ARTIFACTORY_URL','https://repository.deere.com/artifactory/parts-hcs-snapshot','Artifactory URL')
            stringParam('ARTIFACTORY_USER_NAME','adyhcjj','Application Id')
            nonStoredPasswordParam('ARTIFACTORY_PASSWORD','')
            stringParam('GROUP','com.deere.parts.hcs','Optional: Project artifact group id i.e., com.deere.aws.assetapi')
            stringParam('ARTIFACT','deere-hybris','Optional: Project artifact name i.e., asset-api')
            stringParam('FILE_TYPE','.zip','Optional: Project artifact name i.e., asset-api')
            stringParam('VERSION','1.0-SNAPSHOT','Optional: Project artifact version i.e., 1.0-RELEASE')
            stringParam('ACCOUNT_NAME','aws-parts-ecommerce-devl','Optional: Account name to be considered for the deployment infrastructure i.e., jd-us01-ea-sharedservicesdevl')
            stringParam("ACCOUNT_NUMBER", "809731660233", "Account Number to provision stack. 424055927146 for ea-devl")
            stringParam("ROLE_NAME", "jenkins/appslave-jenkins-partsecommerceapps", "Role Name to assume for provisioning stack.")
            stringParam('REGION','us-east-1','Required: Deployment region i.e., us-east-1')
            stringParam('BUCKET_NAME','aws-parts-ecommerce-devl-hcs','Required: S3 bucket for app aws package bundle i.e., jd-us01-ea-sharedservicesdevl-deployment')
            stringParam('DEPLOYMENT_GROUP_NAME',"hcstest-deployment-group",'Required: Deployment group i.e., cloud-platform-assetapi-gateway')
    }

    wrappers {
      preBuildCleanup()
      maskPasswords()
    }
    steps {
        shell('''#!/bin/bash
set -e
DEPLOYMENT_SCRIPTS_DIR=$WORKSPACE'/aws-codedeploy-scripts/hcs/devl'
APPSPEC_CONFIG=$WORKSPACE'/aws-codedeploy-scripts/hcs/devl/appspec.yml'
BEF_INSTALL_CONFIG=$WORKSPACE'/aws-codedeploy-scripts/hcs/devl/before_install.sh'
AFT_INSTALL_CONFIG=$WORKSPACE'/aws-codedeploy-scripts/hcs/devl/after_install.sh'
APP_START_CONFIG=$WORKSPACE'/aws-codedeploy-scripts/hcs/devl/application_start.sh'
APP_STOP_CONFIG=$WORKSPACE'/aws-codedeploy-scripts/hcs/devl/application_stop.sh'

echo 'seeding env'
sed -i "s/__ENV__/$MYENV/g" $AFT_INSTALL_CONFIG
sed -i "s/\\${ARTIFACT}/$ARTIFACT/g" $APPSPEC_CONFIG

sed -i "s/\\${ARTIFACT}/$ARTIFACT/g" $BEF_INSTALL_CONFIG

sed -i "s/\\${ARTIFACT}/$ARTIFACT/g" $AFT_INSTALL_CONFIG

sed -i "s/\\${ARTIFACT}/$ARTIFACT/g" $APP_STOP_CONFIG

sed -i "s/\\${ARTIFACT}/$ARTIFACT/g" $APP_START_CONFIG
#sed -i "s/\\${ENV_CONFIG_SUFFIX}/$ENV_CONFIG_SUFFIX/g" $APP_START_CONFIG
sed -i "s/\\${FILE_TYPE}/$FILE_TYPE/g" $APP_START_CONFIG
sed -i "s/\\${VERSION}/$VERSION/g" $APP_START_CONFIG
#sed -i "s/\\${CLASSIFIER}/$CLASSIFIER/g" $APP_START_CONFIG
#sed -i "s/\\${MAIN_CLASS}/$MAIN_CLASS/g" $APP_START_CONFIG

echo 'updated application start configuration'

python --version

echo 'deployment start...'
python -m cloud_common.aws_code_deploy \\
                        --deploy_application $DEPLOY_APPLICATION_NAME \\
                        --artifactoryurl $ARTIFACTORY_URL \\
                        --group $GROUP \\
                        --artifact $ARTIFACT \\
                        --version $VERSION \\
                        --file_type $FILE_TYPE \\
                        --account_number $ACCOUNT_NUMBER \\
                        --deployment_scripts $DEPLOYMENT_SCRIPTS_DIR \\
                        --role_name $ROLE_NAME \\
                        --bucket_name $BUCKET_NAME \\
                        --region $REGION \\
                        --deployment_group $DEPLOYMENT_GROUP_NAME \\
                        --username $ARTIFACTORY_USER_NAME \\
                        --encryptedPassword $ARTIFACTORY_PASSWORD \\
                        --log INFO \\

echo 'deployment completed.'
            ''')
    }
    publishers {
        wsCleanup {
            deleteDirectories(true)
            setFailBuild(false)
        }
    }
}
