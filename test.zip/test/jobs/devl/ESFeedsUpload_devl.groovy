freeStyleJob("hcs_57/ESFeedsUpload-devl") {
    description 'This jenkins job is used to copy all media from s3 to efs'
    logRotator(daysToKeep = -1, numToKeep = 10, artifactDaysToKeep = -1, artifactNumToKeep = -1)
    label('devl-slave')


    parameters {

      		stringParam("INSTANCEID", "", "Please enter the integration instance ID: i-0f290a79712ab1b65")
			fileParam('ESFeeds.zip', 'my description')
    }

    wrappers {
      preBuildCleanup()
      maskPasswords()
    }

    steps {
        shell( '''#!/bin/bash
set +x
   {
LOG_DIR=/var/lib/jenkins/workspace/hcs_57/ESFeedsUpload-Test-devl

        mkdir -p $LOG_DIR/employeestore
        mkdir -p $LOG_DIR/employeestore/hotfolder
		mkdir -p $LOG_DIR/employeestore/hotfolder/processing
        ls -l

		echo "copying the es files to integration folder"
        cd $LOG_DIR/employeestore
        cp $LOG_DIR/ESFeeds.zip $LOG_DIR/employeestore
        unzip -o 'ESFeeds.zip' < /dev/null
        pwd
		
        echo "below files coping in hotfolder directory"
        [ -f employeeStoreProduct-*.csv ] &&  cp -rvf employeeStoreProduct-*.csv hotfolder/ || echo "employeeStoreProduct-*.csv does not exist"
        [ -f employeeStoreCategory-*.csv ] &&  cp -rvf employeeStoreCategory-*.csv hotfolder/ || echo "employeeStoreCategory-*.csv does not exist"
        [ -f employeeStoreProductToCategory-*.csv ] && cp -rv employeeStoreProductToCategory-*.csv hotfolder/ || echo "employeeStoreProductToCategory-*.csv does not exist"
		[ -f employeeProductToAvailabilityAssignment-*.csv ] && cp -rv employeeProductToAvailabilityAssignment-*.csv hotfolder/ || echo "employeeProductToAvailabilityAssignment-*.csv does not exist"

        rm -rf ESFeeds.zip employeeStoreProduct-*.csv employeeStoreCategory-*.csv employeeStoreProductToCategory-*.csv employeeProductToAvailabilityAssignment-*.csv
    	ls -l hotfolder

        echo "uploading files in S3"
    	echo
        aws s3 sync /var/lib/jenkins/workspace/hcs_57/ESFeedsUpload-Test-devl/employeestore/ s3://aws-parts-ecommerce-devl-hybrislogs/hcsintegrationbackup/jdb2c/employeestore/ --delete --sse AES256
    	echo
        echo "downloading files from S3 to integration server"
        echo

     {

			COMMANDS="[\\"aws s3 --region us-east-1 cp s3://aws-parts-ecommerce-devl-hybrislogs/hcsintegrationbackup/jdb2c/employeestore/ /www/mounts/integration/jdb2c/employeestore/ --recursive --sse AES256 && chown -R hcsuser:hcsgroup /www/mounts/integration/jdb2c/employeestore/ \\"]"
			echo $INSTANCEID
			if [ `echo "$INSTANCEID" ` ]; then

			sh_command_id=$(aws ssm send-command \
                  --document-name "AWS-RunShellScript" \
                  --targets Key=instanceids,Values=$INSTANCEID \
                  --parameters "{\\"commands\\":$COMMANDS,\\"executionTimeout\\":[\\"7200\\"]}" \
                  --timeout-seconds 600  \
                  --region us-east-1  --output text --query "Command.CommandId")
            echo $sh_command_id


		    fi
             echo 'ES Files Uploaded successfully.'

			}

 	 }

        ''')
    }
}
