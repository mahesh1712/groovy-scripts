branch = "master"
git_url = "https://github.deere.com/ECommerce/ecommerce-hcs-infra"


freeStyleJob("hcs_57/start-stop-solr-devl") {
    description 'Starts/Stops solr instances'
    logRotator(daysToKeep = -1, numToKeep = 10, artifactDaysToKeep = -1, artifactNumToKeep = -1)
    label('devl-slave')

    parameters {
            choiceParam("OPERATION", ["start","stop","restart"])
            choiceParam("NODE_GROUP", ["master","slave","master,slave"])
    }

    wrappers {
      preBuildCleanup()
      maskPasswords()
    }
    steps {
        shell('''#!/bin/bash
set -e

TAG_NAME_MASTER=hcssolrMASTER-EC2
TAG_NAME_SLAVE=hcssolrSLAVE1-EC2

function sendCommand {
        local START_SERVER='service solr start'
        local STOP_SERVER='service solr stop'
        local RESTART_SERVER='service solr restart'
        local ADD_LOG_ENTRY="echo $OPERATION >> /tmp/testSSM.txt"

        local TAG_VALUES="[\\"$1\\"]"

        local COMMANDS=""

        case $OPERATION in
                start)
                        COMMANDS="[\\"$START_SERVER\\","
                        ;;
                stop)
                        COMMANDS="[\\"$STOP_SERVER\\","
                        ;;
                restart)
                        COMMANDS="[\\"$STOP_SERVER\\",\\"$START_SERVER\\","
                        ;;
        esac

        COMMANDS=$COMMANDS"\\"$ADD_LOG_ENTRY\\"]"

        echo Destination: $TAG_VALUES
        echo $COMMANDS
        echo "{\\"Key\\":\\"tag:component\\",\\"Values\\":$TAG_VALUES}"

        aws ssm send-command \\
                --document-name "AWS-RunShellScript" \\
				--targets Key=tag:Name,Values=$TAG_VALUES Key=tag:component,Values=hybris \\
                --parameters "{\\"commands\\":$COMMANDS,\\"executionTimeout\\":[\\"3600\\"]}" \\
                --timeout-seconds 600 --region us-east-1 \\
                --region us-east-1
}

if [ `echo "$NODE_GROUP" | grep 'master'` ]; then
        sendCommand $TAG_NAME_MASTER
fi

if [ `echo "$NODE_GROUP" | grep 'slave'` ]; then
        sendCommand $TAG_NAME_SLAVE
fi

echo 'Start/Stop Job completed.'
echo 'Note: in case of application start, please wait for 8-10 mins'
            ''')
    }
}
