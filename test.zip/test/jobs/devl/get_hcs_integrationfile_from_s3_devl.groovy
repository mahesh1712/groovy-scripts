
freeStyleJob('hcs_57/get-hcs-integrationfile-from-s3-devl') {
    logRotator(numToKeep = 100)
    label('devl-slave')
    wrappers {
        preBuildCleanup()
    }
    parameters {
        stringParam('source_file_path','' , "Give the S3 file path. example: jdb2c/error/error_jdprice_000000008546483920181114-224927-410.csv")
        stringParam('destination_file_name','', "Give the full destiation file name. example: error_jdproduct-000000000087414120180924-053555-586.csv")
    }

    steps {
        shell( '''
#!/bin/bash
set +x

echo "##################START LISTING FROM S3 BUCKET ############################"

aws --region us-east-1 s3 ls s3://aws-parts-ecommerce-devl-hybrislogs/hcsintegrationbackup/${source_file_path} --recursive --sse AES256

echo "##################END LISTING FROM S3 BUCKET ##############################"

echo "################## START TO GETINTEGRATIONFILE FROM S3 BUCKET ############################"

aws --region us-east-1 s3 cp s3://aws-parts-ecommerce-devl-hybrislogs/hcsintegrationbackup/${source_file_path} ${destination_file_name} --sse AES256

echo "##################END GETINTEGRATIONFILE FROM S3 BUCKET ############################"

echo "################## START PRINTING DESTINATION FILE ############################"

cat ${destination_file_name}

echo "##################END PRINTING DESTINATION FILE ############################"
set -x

        ''')
    }
}
