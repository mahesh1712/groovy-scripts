branch = "\${branch}"
git_url = "https://github.deere.com/ECommerce/ecommerce-hcs-new.git"

freeStyleJob("hcs_57/hcs_57_build") {
   logRotator(daysToKeep = -1, numToKeep = 15, artifactDaysToKeep = -1, artifactNumToKeep = -1)
    label('devl-slave')

	scm {
        git {
            remote {
                url("${git_url}")
                credentials("fd03e872-1891-4843-ab9a-f5c88f89bfc5")
            }
            branch("${branch}")
            extensions {
            }
        }

    }
    	parameters {
            stringParam('HYBRIS_COMMERCE_SUITE','CXCOMM201100P_6-70005693.zip', "For 1811 Build =  CXCOMM181100P_16-70004085.ZIP     For 2011 Build =  CXCOMM201100P_6-70005693.zip")
            stringParam('HYBRIS_OPT_CONFIG_DIR','${WORKSPACE}/hybris/env/ci')
          	choiceParam("branch", ["master","develop","release-oct2021","release-25thOct21"])


  }

    wrappers {
      preBuildCleanup()
      maskPasswords()
    }

    steps {
        shell('''#!/bin/bash
if [ $HYBRIS_COMMERCE_SUITE == "CXCOMM181100P_16-70004085.ZIP" ]
then
	sudo update-alternatives --set java /usr/lib/jvm/java-1.8.0-amazon-corretto.x86_64/jre/bin/java
elif [ $HYBRIS_COMMERCE_SUITE == "CXCOMM201100P_6-70005693.zip" ]
then
	sudo update-alternatives --set java /usr/lib/jvm/java-11-amazon-corretto.x86_64/bin/java
fi

echo "=============================="
echo "=====CURRENT JAVA VERSION====="
java -version
echo "=====CURRENT JAVA VERSION====="
echo "=============================="
	   ''')
    }
    steps {
        ant {

            targets(['install'])
            props('environment': 'ci','hybris.zip.package.src': '../hcs-57-hybris-install-media-test/${HYBRIS_COMMERCE_SUITE}')
            antInstallation('Ant Install Auto Initially 1.10.9')

        }
        ant {
            targets(['clean', 'customize', 'all', 'production'])
            props('environment': 'ci','hybris.zip.package.src': '../hcs-57-hybris-install-media-test/${HYBRIS_COMMERCE_SUITE}')
            antInstallation('Ant Install Auto Initially 1.10.9')

        }
    }

    steps {
        shell('''
zip -j deere-hybris.zip hybris/temp/hybris/hybrisServer/*.zip
cd hybris/temp/hybris/hybrisServer/
unzip hybrisServer-solr.zip

if [ $HYBRIS_COMMERCE_SUITE == "CXCOMM181100P_16-70004085.ZIP" ]
then
	cp -rf /var/lib/jenkins/workspace/hcs_57/hcs_57_build/hybris/env/common/solr/configsets/default/conf/solrconfig.xml /var/lib/jenkins/workspace/hcs_57/hcs_57_build/hybris/temp/hybris/hybrisServer/hybris/bin/ext-commerce/solrserver/resources/solr/7.7/server/server/solr/configsets/default/conf/solrconfig.xml
	mv hybris/bin/ext-commerce/solrserver/resources/solr .
elif [ $HYBRIS_COMMERCE_SUITE == "CXCOMM201100P_6-70005693.zip" ]
then
	cp -rf /var/lib/jenkins/workspace/hcs_57/hcs_57_build/hybris/env/common/solr/configsets/default/conf/solrconfig.xml /var/lib/jenkins/workspace/hcs_57/hcs_57_build/hybris/temp/hybris/hybrisServer/hybris/bin/modules/search-and-navigation/solrserver/resources/solr/8.6/server/server/solr/configsets/default/conf/solrconfig.xml
	mv hybris/bin/modules/search-and-navigation/solrserver/resources/solr .
fi


#rm -r hybris
tar -czvf deere-solr.tgz solr
#rm -r solr

	   ''')
    }

    steps {
        shell('''
#echo "Uploading Hybris zip..."
#curl -X PUT -u adyhcjj:${artifactorypassword} -T deere-hybris.zip "https://repository.deere.com/artifactory/parts-hcs-snapshot-local/com/deere/parts/hcs/deere-hybris/1.0-SNAPSHOT/deere-hybris-1.0-SNAPSHOT.zip"
#echo "Uploading Solr zip..."
#curl -X PUT -u adyhcjj:${artifactorypassword} -T hybris/temp/hybris/hybrisServer/deere-solr.tgz "https://repository.deere.com/artifactory/parts-hcs-snapshot-local/com/deere/parts/hcs/deere-solr/1.0-SNAPSHOT/deere-solr-1.0-SNAPSHOT.tgz"
	   ''')
    }

}
