
freeStyleJob('hcs_57/upload_an_image_s3_devl') {
    logRotator(numToKeep = 100)
    label('qual-slave')
    wrappers {
        preBuildCleanup()
    }
    parameters {
        fileParam('copy an image', "Choose the Source path here")

    }

    steps {
        shell( '''
#!/bin/bash


################## UNCOMMENT LINES BELOW TO UPLOAD TO S3 BUCKET ############################

aws --region us-east-1 s3 cp test.png s3://aws-parts-ecommerce-devl-hcsdesigner/ --sse AES256

##################END UNCOMMENT LINES BELOW TO CREATE KEY PAIR ############################

##################START UNCOMMENT LINES BELOW TO DELETE FROM S3 BUCKET ############################
#aws --region us-east-1 s3 rm s3://${BUCKET_NAME}/ --recursive
##################END UNCOMMENT LINES BELOW TO DELETE KEY PAIR ############################
        ''')
    }
}
