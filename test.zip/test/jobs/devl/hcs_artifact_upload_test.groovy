    freeStyleJob("hcs_57/hcs_artifact_upload-test") {
       logRotator(daysToKeep = -1, numToKeep = 15, artifactDaysToKeep = -1, artifactNumToKeep = -1)
        label('devl-slave')

        	parameters {
                nonStoredPasswordParam('artifactorypassword','')

      }

        wrappers {
          preBuildCleanup()
          maskPasswords()
        }

        steps {
            shell('''
    cp ../hcs_57_build/deere-hybris.zip .
    cp ../hcs_57_build/hybris/temp/hybris/hybrisServer/deere-solr.tgz .
    	   ''')
        }

    	steps {
            shell('''
    echo "Uploading Hybris zip..."
    curl -X PUT -u adyhcjj:${artifactorypassword} -T deere-hybris.zip "https://repository.deere.com/artifactory/parts-hcs-snapshot-local/com/deere/parts/hcs/deere-hybris/1.0-SNAPSHOT/deere-hybris-1.0-SNAPSHOT.zip"

    echo "Uploading Solr zip..."
    curl -X PUT -u adyhcjj:${artifactorypassword} -T deere-solr.tgz "https://repository.deere.com/artifactory/parts-hcs-snapshot-local/com/deere/parts/hcs/deere-solr/1.0-SNAPSHOT/deere-solr-1.0-SNAPSHOT.tgz"

    	   ''')
        }
    }
