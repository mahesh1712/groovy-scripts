branch = "*/master"
git_url = "https://github.deere.com/ECommerce/ecommerce-hcs-new.git"

freeStyleJob("hcs_57/hcs-build-test") {
   logRotator(daysToKeep = -1, numToKeep = 15, artifactDaysToKeep = -1, artifactNumToKeep = -1)
    label('devl-slave')

	scm {
        git {
            remote {
                url("${git_url}")
                credentials('hcs-code-repo-id')
            }
            branch("${branch}")
            extensions {
            }
        }

    }
    	parameters {
            stringParam('HYBRIS_COMMERCE_SUITE','HYBRISCOMM6300P_7-70002554.zip', "HYBRISCOMM6300P_7-70002554.zip,HYBRISCOMM6500P_3-80003045.ZIP")
            stringParam('HYBRIS_OPT_CONFIG_DIR','${WORKSPACE}/hybris/env/ci')
          	choiceParam("branch", ["hybrislighty","hybrisaws"])
          	nonStoredPasswordParam('artifactoryEncryptedPassword','')


  }

    wrappers {
      preBuildCleanup()
      maskPasswords()
    }

    steps {
        shell('''
ant -version
	   ''')
    }

    steps {
        ant {

            targets(['install'])
            props('environment': 'ci','hybris.zip.package.src': '../hcs_57_hybris_install_media/${HYBRIS_COMMERCE_SUITE}')
            antInstallation('Ant Install Auto Initially 1.10.3')

        }
        ant {
            targets(['clean', 'customize', 'all', 'production'])
            props('environment': 'ci','hybris.zip.package.src': '../hcs_57_hybris_install_media/${HYBRIS_COMMERCE_SUITE}')
            antInstallation('Ant Install Auto Initially 1.10.3')

        }
    }

    steps {
        shell('''
zip -j deere-hybris.zip hybris/temp/hybris/hybrisServer/*.zip
cd hybris/temp/hybris/hybrisServer/
unzip hybrisServer-solr.zip

#moving the custom configrations from "hybris/config/solr/configsets/"
#cp -rf /var/lib/jenkins/workspace/hcs_57/hcs_57_build/hybris/config/solr/configsets/ /var/lib/jenkins/workspace/hcs_57/hcs_57_build/hybris/bin/ext-commerce/solrserver/resources/solr/server/solr/

cp -rf /var/lib/jenkins/workspace/hcs_57/hcs_57_build/hybris/config/solr/configsets/ /var/lib/jenkins/workspace/hcs_57/hcs_57_build/hybris/temp/hybris/hybrisServer/hybris/bin/ext-commerce/solrserver/resources/solr/server/solr/
mv hybris/bin/ext-commerce/solrserver/resources/solr .

#rm -r hybris
tar -czvf deere-solr.tgz solr
#rm -r solr

	   ''')
    }

    steps {
        shell('''
#echo "Uploading Hybris zip..."
#curl -X PUT -u adyhcjj:${artifactorypassword} -T deere-hybris.zip "https://repository.deere.com/artifactory/parts-hcs-snapshot-local/com/deere/parts/hcs/deere-hybris/1.0-SNAPSHOT/deere-hybris-1.0-SNAPSHOT.zip"
#echo "Uploading Solr zip..."
#curl -X PUT -u adyhcjj:${artifactorypassword} -T hybris/temp/hybris/hybrisServer/deere-solr.tgz "https://repository.deere.com/artifactory/parts-hcs-snapshot-local/com/deere/parts/hcs/deere-solr/1.0-SNAPSHOT/deere-solr-1.0-SNAPSHOT.tgz"
	   ''')
    }

}
