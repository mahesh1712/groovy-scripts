branch = "master"
git_url = "https://github.deere.com/ECommerce/ecommerce-hcs-infra"
pipelineJob('hcs_57/hcsbo-deploy-pipeline-devl') {
	parameters {
		    stringParam('DEPLOY_APPLICATION_NAME',"hcsbo-codedeploy-application",'Required: Code deploy application name associated with given code deployment group i.e., asset-api')
            stringParam('MYENV',"devl",'Environment')
            stringParam('ACCOUNT_NAME','aws-parts-ecommerce-devl','Optional: Account name to be considered for the deployment infrastructure i.e., jd-us01-ea-sharedservicesdevl')
            stringParam("ACCOUNT_NUMBER", "809731660233", "Account Number to provision stack. 075198429380 for aws-parts-apps-devl")
            stringParam("ROLE_NAME", "jenkins/appslave-jenkins-partsecommerceapps", "Role Name to assume for provisioning stack.")
            stringParam('REGION','us-east-1','Required: Deployment region i.e., us-east-1')
            stringParam('BUCKET_NAME','aws-parts-ecommerce-devl-hcs','Required: S3 bucket for app aws package bundle i.e., aws-parts-apps-devl-hcs')
            stringParam('DEPLOYMENT_GROUP_NAME',"hcsbo-deployment-group",'Required: Deployment group i.e., cloud-platform-assetapi-gateway')
	}
    definition {
        cpsScm {
			scm {
				git {
					remote {
						url("${git_url}")
						credentials('hcs-infra-github-token')
					}
					branch("${branch}")
					extensions {
					}
				}
			}
			scriptPath('jobs/devl/hcs_deploypipeline_devl')
        }
    }
}