freeStyleJob('hcs_57/delete-hcs-rds-manual-snapshot-devl') {
    logRotator(numToKeep = 100)
    label('devl-slave')
    parameters {
        stringParam("HCS_RDS_CLUSTER_ID", "hcs-rds-stack-hcsrdsrdscluster-a3vnp1osjgep", "HCS RDS Cluster Identifier for Source DB")
        stringParam("ACCOUNT_NUMBER", "809731660233", "AWS Account Number")
        stringParam("ACCOUNT_ALIAS", "aws-parts-ecommerce")
        stringParam("ENVIRONMENT", "devl")
        stringParam("ROLE_NAME", "jenkins/appslave-jenkins-partsecommerceapps")
     }
    triggers {
       cron('0 3 * * *')
    }
    steps {
        //Please keep indentation as shown below to avoid issues in the script.
        shell('''#!/bin/bash
aws rds describe-db-cluster-snapshots --db-cluster-identifier $HCS_RDS_CLUSTER_ID --snapshot-type manual --query 'DBClusterSnapshots[0:-4].[DBClusterSnapshotIdentifier]' --output text --no-paginate --region us-east-1 |
while read line;
do aws rds delete-db-cluster-snapshot --db-cluster-snapshot-identifier $line --region us-east-1;
done
        ''')

    }
}
