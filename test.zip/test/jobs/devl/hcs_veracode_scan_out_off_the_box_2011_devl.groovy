freeStyleJob("hcs_57/hcs_veracode_scan_out_off_the_box_2011_devl") {
	description 'veracode scan for hcs out off the box jar'
    logRotator(daysToKeep = -1, numToKeep = 5, artifactDaysToKeep = -1, artifactNumToKeep = -1)
    label('devl-slave')
	wrappers {
		preBuildCleanup {
			deleteDirectories(false)
			cleanupParameter()
		}
	}
	
	 triggers {
        cron('00 00 1,15 * *')
    }
    steps { 
		python {
		nature("python")
		command("""#!/usr/bin/python
import os, sys
import subprocess,re,shutil
rootlocation='/var/lib/jenkins/workspace/hcs_57/hcs_57_build/'
storefrontlocation='/var/lib/jenkins/workspace/hcs_57/hcs_57_build/hybris/bin/custom/jdb2c/jdb2cstorefront/web/webroot/WEB-INF'
folderdirectory='WEB_INF'
createLibDir=folderdirectory+'/lib'
if not os.path.exists(folderdirectory):
	os.mkdir( folderdirectory, 0755 );
if not os.path.exists(createLibDir):
	os.mkdir( createLibDir, 0755 );
shutil.copytree(storefrontlocation+'/classes',folderdirectory+'/classes');
shutil.copytree(storefrontlocation+'/messages',folderdirectory+'/messages');
shutil.copytree(storefrontlocation+'/tags',folderdirectory+'/tags');
shutil.copytree(storefrontlocation+'/tld',folderdirectory+'/tld');
shutil.copytree(storefrontlocation+'/views',folderdirectory+'/views');
shutil.copy(storefrontlocation+'/web.xml',folderdirectory);
		""")
    }
	ant {
		targets(['production', '-Dproduction.create.zip=false', "-logfile /var/lib/jenkins/workspace/hcs_57/hcs_veracode_scan_out_off_the_box_2011_devl/testtwo.txt"])
		buildFile('/var/lib/jenkins/workspace/hcs_57/hcs_57_build/build.xml')
		props('environment': 'production', 'hybris.zip.package.src': '../hcs-57-hybris-install-media-test/CXCOMM201100P_6-70005693.zip')
		antInstallation('Ant Install Auto Initially 1.10.9')
	}
	python {
	nature("python")
command("""#!/usr/bin/python
import os, sys
import subprocess,re,shutil
folderdirectory='WEB_INF'
createLibDir=folderdirectory+'/lib'
rootlocation='/var/lib/jenkins/workspace/hcs_57/hcs_57_build/'
customfolderlocation=rootlocation+'/hybris/bin'
shakes = open('/var/lib/jenkins/workspace/hcs_57/hcs_veracode_scan_out_off_the_box_2011_devl/testtwo.txt', "r")
searchlocation="      [jar] Building jar: "
OOTBsearch="/modules"
for line in shakes:
	if re.match("(.*)Building jar(.*)", line):
		pathfound=line.split(searchlocation,1)[1]
		if re.match("(.*)"+OOTBsearch+"(.*)",pathfound):
			shutil.copy(pathfound.rstrip(),folderdirectory+'/lib')
for root, dirs, files in os.walk(customfolderlocation):
	for file in files:
		if file.startswith('jdb2c'):
			continue
		elif file.endswith('.jar'):
			jarfilelocation=root+'/'+str(file)
			shutil.copy(jarfilelocation,createLibDir)
if os.path.exists(folderdirectory+'/lib/log4j-api-2.13.2.jar'):
  os.remove(folderdirectory+'/lib/log4j-api-2.13.2.jar')
if os.path.exists(folderdirectory+'/lib/log4j-api-2.13.3.jar'):
  os.remove(folderdirectory+'/lib/log4j-api-2.13.3.jar')
if os.path.exists(folderdirectory+'/lib/log4j-api-2.15.0.jar'):
  os.remove(folderdirectory+'/lib/log4j-api-2.15.0.jar')
if os.path.exists(folderdirectory+'/lib/log4j-core-2.13.2.jar'):
  os.remove(folderdirectory+'/lib/log4j-core-2.13.2.jar')
if os.path.exists(folderdirectory+'/lib/log4j-core-2.13.3.jar'):
  os.remove(folderdirectory+'/lib/log4j-core-2.13.3.jar')
if os.path.exists(folderdirectory+'/lib/log4j-core-2.15.0.jar'):
  os.remove(folderdirectory+'/lib/log4j-core-2.15.0.jar')
if os.path.exists(folderdirectory+'/lib/log4j-1.2-api-2.13.2.jar'):
  os.remove(folderdirectory+'/lib/log4j-1.2-api-2.13.2.jar')
subprocess.call('/usr/bin/jar -cvf JDStore.jar WEB_INF',shell=True,cwd='/var/lib/jenkins/workspace/hcs_57/hcs_veracode_scan_out_off_the_box_2011_devl')
""")
	}
	
shell('''#!/bin/bash
set -e
mkdir packages
cp JDStore.jar packages/JDStore.jar

wget https://repo1.maven.org/maven2/com/veracode/vosp/api/wrappers/vosp-api-wrappers-java/21.6.8.0/vosp-api-wrappers-java-21.6.8.0-dist.zip
unzip vosp-api-wrappers-java-21.6.8.0-dist.zip
tar -cvzf $WORKSPACE/veracode_packet.tar.gz packages/*.jar

java -jar VeracodeJavaAPI.jar -action uploadandscan -vid 02637059de9694026b51cb2928c2c7eb -vkey 2c6c89072587d7719a5f525347464922c8bd0356446523ca94c2aa37d501d593decff70c82bb964be4fa09e03277aa6bd038665d57ec77589c78c49840c734e3 -appname PARTS_HCS_SAP -createprofile false -criticality VeryHigh -version HCS_SAP_${BUILD_NUMBER} -scantimeout 100 -selected true -include JDStore.jar -filepath $WORKSPACE/veracode_packet.tar.gz > output.txt 2>&1

echo upload_scan_results=$(cat output.txt)
buildid=$(cat output.txt | grep "The analysis id of the new analysis is" | cut -d '"' -f2)
echo $buildid

java -jar VeracodeJavaAPI.jar -vid 02637059de9694026b51cb2928c2c7eb -vkey 2c6c89072587d7719a5f525347464922c8bd0356446523ca94c2aa37d501d593decff70c82bb964be4fa09e03277aa6bd038665d57ec77589c78c49840c734e3 -action detailedreport -buildid $buildid -format pdf -outputfilepath detailedreport.pdf

            ''')
  }
  publishers{

        extendedEmail {
            triggers {
				success {
						recipientList('DCEECommerceSquadron@JohnDeere.com')
						subject("HCS 2011.6 OOTB Veracode Scan Report")
						contentType('text/html')
						content("Veracode scan successfully completed for 2011.6 version. Please find attached reports. <p style='color:red'>This is autogenerated email, from Jenkins.</p>")
						attachmentPatterns("*.pdf")
				
				
				}
            }
        }		
	}
}