listView('hcs_57/DEVL JOBS') {
	    description("Jobs for Development Environment")
	    jobs {
	        regex(
	            '.*devl'
	        )
	    }
	    columns {
	        status()
	        weather()
	        name()
	        lastSuccess()
	        lastFailure()
	        lastDuration()
	       buildButton()
	    }
	}
