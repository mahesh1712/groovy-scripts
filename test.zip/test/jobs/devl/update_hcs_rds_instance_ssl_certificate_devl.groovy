freeStyleJob('hcs_57/update-hcs-rds-instance-ssl-certificate-devl') {
    logRotator(numToKeep = 100)
    label('devl-slave')
    parameters {
        stringParam("ACCOUNT_NUMBER", "809731660233", "Account Number to provision stack")
        stringParam("ACCOUNT_ALIAS", "aws-parts-ecommerce")
        stringParam("ENVIRONMENT", "devl")
        stringParam("ROLE_NAME", "jenkins/appslave-jenkins-partsecommerceapps", "Jenkins role")
        stringParam("db_instance_identifier","", "Db Instance Identifier")
        stringParam("ca_certificate_identifier","", "ca certificate identifier")
        choiceParam("Apply_Immediately", ["no-apply-immediately", "apply-immediately"])
     }
     steps {
         //Please keep indentation as shown below to avoid issues in the script.
         shell('''#!/bin/bash

# Modify all the instances in Aurora cluster
aws rds modify-db-instance --db-instance-identifier $db_instance_identifier \
--ca-certificate-identifier $ca_certificate_identifier --$Apply_Immediately  --region us-east-1
         ''')

     }
 }
