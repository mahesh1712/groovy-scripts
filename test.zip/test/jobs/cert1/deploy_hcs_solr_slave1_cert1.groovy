branch = "master"
git_url = "https://github.deere.com/ECommerce/ecommerce-hcs-infra"

freeStyleJob("hcs_57/deploy-hcs-solr-slave1-cert1") {
    description 'Deploys app to a given account'
    logRotator(daysToKeep = 365, numToKeep = 10, artifactDaysToKeep = -1, artifactNumToKeep = -1)
	label('cert-slave')

	scm {
        git {
            remote {
                url("${git_url}")
                credentials('hcs-infra-github-token')
            }
            branch("${branch}")
            extensions {
            }
        }

    }
    parameters {
            stringParam('DEPLOY_APPLICATION_NAME',"hcssolrcert1-slave1-codedeploy-application",'Required: Code deploy application name associated with given code deployment group i.e., asset-api')
			stringParam('MYENV',"cert1",'Environment')
            stringParam('ARTIFACTORY_URL','https://repository.deere.com/artifactory/parts-hcs-snapshot','Artifactory URL')
            stringParam('GROUP','com.deere.parts.hcs','Optional: Project artifact group id i.e., com.deere.aws.assetapi')
            stringParam('ARTIFACT','deere-solr','Optional: Project artifact name i.e., asset-api')
            stringParam('FILE_TYPE','.tgz','Optional: Project artifact name i.e., asset-api')
            //stringParam('VERSION','1.0-SNAPSHOT','Optional: Project artifact version i.e., 1.0-RELEASE')
			choiceParam("VERSION", ["1.0-SNAPSHOT","1.1-SNAPSHOT"],"Please select 1.0-SNAPSHOT=> 1811 Codebase & 1.1-SNAPSHOT=> 2011 Codebase ")
            stringParam('ACCOUNT_NAME','aws-parts-ecommerce-cert','Optional: Account name to be considered for the deployment infrastructure i.e., jd-us01-ea-sharedservicescert1')
            stringParam("ACCOUNT_NUMBER", "122749220977", "Account Number to provision stack. 075198429380 for aws-parts-apps-cert1")
            stringParam("ROLE_NAME", "jenkins/appslave-jenkins-partsecommerceapps", "Role Name to assume for provisioning stack.")
            stringParam('REGION','us-east-1','Required: Deployment region i.e., us-east-1')
            stringParam('BUCKET_NAME','aws-parts-ecommerce-cert1-hcs','Required: S3 bucket for app aws package bundle i.e., aws-parts-apps-cert1-hcs')
            stringParam('DEPLOYMENT_GROUP_NAME',"hcssolrcert1-slave1-deployment-group",'Required: Deployment group i.e., cloud-platform-assetapi-gateway')

    }
    wrappers {
      preBuildCleanup()
      maskPasswords()
    }
    steps {
        shell('''#!/bin/bash
set -e

DEPLOYMENT_SCRIPTS_DIR=$WORKSPACE'/aws-codedeploy-scripts/solr/cert1'
APPSPEC_CONFIG=$WORKSPACE'/aws-codedeploy-scripts/solr/cert1/appspec.yml'
BEF_INSTALL_CONFIG=$WORKSPACE'/aws-codedeploy-scripts/solr/cert1/before_install.sh'
AFT_INSTALL_CONFIG=$WORKSPACE'/aws-codedeploy-scripts/solr/cert1/after_install.sh'
APP_START_CONFIG=$WORKSPACE'/aws-codedeploy-scripts/solr/cert1/application_start.sh'
APP_STOP_CONFIG=$WORKSPACE'/aws-codedeploy-scripts/solr/cert1/application_stop.sh'

echo 'seeding env'

sed -i "s/\\${ARTIFACT}/$ARTIFACT/g" $APPSPEC_CONFIG

sed -i "s/\\${ARTIFACT}/$ARTIFACT/g" $BEF_INSTALL_CONFIG

sed -i "s/\\${ARTIFACT}/$ARTIFACT/g" $AFT_INSTALL_CONFIG

sed -i "s/\\${ARTIFACT}/$ARTIFACT/g" $APP_STOP_CONFIG

sed -i "s/\\${ARTIFACT}/$ARTIFACT/g" $APP_START_CONFIG
#sed -i "s/\\${ENV_CONFIG_SUFFIX}/$ENV_CONFIG_SUFFIX/g" $APP_START_CONFIG
sed -i "s/\\${FILE_TYPE}/$FILE_TYPE/g" $APP_START_CONFIG
sed -i "s/\\${VERSION}/$VERSION/g" $APP_START_CONFIG
sed -i "s/\\ARTIFACT_VERSION/$VERSION/g" $AFT_INSTALL_CONFIG
#sed -i "s/\\${CLASSIFIER}/$CLASSIFIER/g" $APP_START_CONFIG
#sed -i "s/\\${MAIN_CLASS}/$MAIN_CLASS/g" $APP_START_CONFIG

echo 'updated application start configuration'

python --version

echo 'deployment start...'
GROUP_PATH="${GROUP//.//}"

ARTIFACTORY_USER_NAME=adyhcjj
ARTIFACTORY_PASSWORD=$(aws ssm get-parameter --region us-east-1 --name hcsartifactpasswordcert1 --with-decryption | grep Value | awk -F '"' '{print $4}')
wget --user=$ARTIFACTORY_USER_NAME --password="$ARTIFACTORY_PASSWORD" $ARTIFACTORY_URL/$GROUP_PATH/$ARTIFACT/$VERSION/deere-solr-$VERSION.tgz

mkdir deploy
cp -r deere-solr-$VERSION.tgz deploy/
cp -r aws-codedeploy-scripts/solr/$MYENV/* deploy/
tar -C deploy -czvf deere-solr-$VERSION-TEMP.tgz .
#aws --region us-east-1 s3 cp $WORKSPACE/deploy/deere-solr-$VERSION-TEMP.tgz s3://$BUCKET_NAME/deere-solr-$VERSION.tgz --sse AES256

aws --region us-east-1 s3 cp $WORKSPACE/deere-solr-$VERSION-TEMP.tgz s3://$BUCKET_NAME/deere-solr-$VERSION.tgz --sse AES256

deploy_config="CodeDeployDefault.OneAtATime"
deployment_id=$(aws deploy create-deployment --application-name $DEPLOY_APPLICATION_NAME --deployment-config-name $deploy_config --deployment-group-name $DEPLOYMENT_GROUP_NAME --s3-location bucket=$BUCKET_NAME,bundleType=tgz,key=deere-solr-$VERSION.tgz --region=us-east-1 | grep -oP '"deploymentId": "\\K.*?"'|sed 's/"//g')	
echo $deployment_id
echo "****************************************************"
echo "DeploymentID : "$deployment_id
echo "****************************************************"


echo "Waiting for 1 min to check the status of the current deployment ...!"
sleep 60

deployStatus=''
for (( i=0; i<=20; i++ ))
	do
		deployStatus=$(aws deploy get-deployment --deployment-id $deployment_id --region=us-east-1 | grep -oP '"status": "\\K.*?"'|sed 's/"//g')
 		echo "Deployment status: "$deployStatus
 		if [ "$deployStatus" == "Succeeded" ]
		 then		 
			echo $deployment_id " : Deployment Successful" 	
 			break
		elif [ "$deployStatus" == "Failed" ]
 		 then
 			echo $deployment_id " : Deployment Failed"
 			break
		elif [ "$deployStatus" == "InProgress" ]
 		 then
 			echo $deployment_id " : Deployment in Progress, Please wait ...!" 			
		
		fi
		echo "Waiting for 1 min to again check the status of the deployment ..!"
		sleep 60
	done
echo 'deployment completed.'
 
 
#aws logs filter-log-events --log-group-name "$logFileName-/opt/codedeploy-agent/deployment-root/deployment-logs/codedeploy-agent-deployments.log" --log-stream-names "/opt/codedeploy-agent/deployment-root/deployment-logs/codedeploy-agent-deployments.log" --filter-pattern ""${deployment_id}"" --region us-east-1 --max-items 10000 --query events[].message

# Fail build in case of fail deployment
if [ "$deployStatus" == "Failed" ]; then
	exit 1
fi

echo 'deployment completed.'
            ''')
    }
    publishers {
        wsCleanup {
            deleteDirectories(true)
            setFailBuild(false)
        }
    }
}
