branch = "master"
git_url = "https://github.deere.com/ECommerce/ecommerce-hcs-infra"


freeStyleJob("hcs_57/start-stop-hcs-cert1") {
    description 'Starts/Stops hcs instances'
    logRotator(daysToKeep = -1, numToKeep = 10, artifactDaysToKeep = -1, artifactNumToKeep = -1)
    label('cert-slave')

    parameters {
            choiceParam("OPERATION", ["start","stop","restart"])
            choiceParam("NODE_GROUP", ["backoffice","storefront","backoffice,storefront"])
            stringParam('INSTANCEID', ' ', 'Copy HCS Instance ID From AWS Console, Paste Here and Hit Build and if you want to use multiple instance Ids for start/stop use (,) in between e.g. :- i-0de3b850e4ddec3232,i-0de3b850e4ddec2121' )

    }

    wrappers {
      preBuildCleanup()
      maskPasswords()
    }
    steps {
        shell('''#!/bin/bash
set -e

TAG_NAME_STOREFRONT=hcscert1-EC2
TAG_NAME_BACKOFFICE=hcsbocert1-EC2

function sendCommand {
        local START_SERVER='service hybrisPlatform start'
        local STOP_SERVER='service hybrisPlatform stop'
        local RESTART_SERVER='service hybrisPlatform restart'
        local ADD_LOG_ENTRY="echo $OPERATION >> /tmp/testSSM.txt"

        local TAG_VALUES="[\\"$1\\"]"

        local COMMANDS=""

        case $OPERATION in
                start)
                        COMMANDS="[\\"$START_SERVER\\","
                        ;;
                stop)
                        COMMANDS="[\\"$STOP_SERVER\\","
                        ;;
                restart)
                        COMMANDS="[\\"$STOP_SERVER\\",\\"$START_SERVER\\","
                        ;;
        esac

        COMMANDS=$COMMANDS"\\"$ADD_LOG_ENTRY\\"]"

        echo Destination: $TAG_VALUES
        echo $COMMANDS
        echo "{\\"Key\\":\\"tag:component\\",\\"Values\\":$TAG_VALUES}"


        if [ `echo "$NODE_GROUP" ` && `echo "$INSTANCEID" ` ]; then
            aws ssm send-command \\
                  --document-name "AWS-RunShellScript" \\
                  --targets "Key=instanceids,Values=$INSTANCEID" \\
                  --targets Key=tag:Name,Values=$TAG_VALUES Key=tag:component,Values=hybris \\
                  --parameters "{\\"commands\\":$COMMANDS,\\"executionTimeout\\":[\\"3600\\"]}" \\
                  --timeout-seconds 600 \\
                  --region us-east-1
        elif [ `echo "$INSTANCEID" ` ]; then
                aws ssm send-command \\
                  --document-name "AWS-RunShellScript" \\
                  --targets "Key=instanceids,Values=$INSTANCEID" \\
                  --parameters "{\\"commands\\":$COMMANDS,\\"executionTimeout\\":[\\"3600\\"]}" \\
                  --timeout-seconds 600 \\
                  --region us-east-1
        else
            aws ssm send-command \\
                  --document-name "AWS-RunShellScript" \\
                  --targets Key=tag:Name,Values=$TAG_VALUES Key=tag:component,Values=hybris \\
                  --parameters "{\\"commands\\":$COMMANDS,\\"executionTimeout\\":[\\"3600\\"]}" \\
                  --timeout-seconds 600 \\
                  --region us-east-1
        fi
}

if [ `echo "$NODE_GROUP" | grep 'backoffice'` ]; then
        sendCommand $TAG_NAME_BACKOFFICE
fi

if [ `echo "$NODE_GROUP" | grep 'storefront'` ]; then
        sendCommand $TAG_NAME_STOREFRONT
fi

echo 'Start/Stop Job completed.'
echo 'Note: in case of application start, please wait for 8-10 mins'
            ''')
    }
}
