freeStyleJob('hcs_57/create-hcs-rds-pointintime-recovery-step1of4-cluster-cert1') {
    logRotator(numToKeep = 100)
    label('cert-slave')
    parameters {
        stringParam("SOURCE_HCS_RDS_CLUSTER_ID", "", "HCS RDS  Cluster Identifier for Source DB")
        stringParam("TARGET_HCS_RDS_CLUSTER_ID", "", "HCS RDS  Cluster Identifier for Target DB")
        stringParam("HCS_RDS_DBSUBNET_GROUPNAME", "", "HCS RDS  DBSubnetGroup name")
        choiceParam("RECOVERY_OPTION", ["Latest","TimeBased"])
        stringParam("HCS_RDS_TIMESTAMP", "", "Give TimeSTamp in the format 2017-10-14T23:45:00.000Z. This is only needed for RECOVERY_OPTION=TimeBased")
     }
     steps {
         //Please keep indentation as shown below to avoid issues in the script.
         shell('''#!/bin/bash

if [ "$RECOVERY_OPTION" = "TimeBased" ] && [ "$HCS_RDS_TIMESTAMP" ]
then
  # Aurora MYSQL cluster point in time recovery- create cluster and db instances. Cluster SecurityGroup modified in a separate job.
  aws rds restore-db-cluster-to-point-in-time --db-cluster-identifier ${TARGET_HCS_RDS_CLUSTER_ID} \
  --source-db-cluster-identifier ${SOURCE_HCS_RDS_CLUSTER_ID} --restore-to-time ${HCS_RDS_TIMESTAMP} \
  --db-subnet-group-name ${HCS_RDS_DBSUBNET_GROUPNAME} --region us-east-1

else
  # Aurora MYSQL cluster point in time recovery- create cluster and db instances. Cluster SecurityGroup modified in a separate job.
  aws rds restore-db-cluster-to-point-in-time --db-cluster-identifier ${TARGET_HCS_RDS_CLUSTER_ID} \
  --source-db-cluster-identifier ${SOURCE_HCS_RDS_CLUSTER_ID} --use-latest-restorable-time \
  --db-subnet-group-name ${HCS_RDS_DBSUBNET_GROUPNAME} --region us-east-1
fi

####Start below section can be uncommented to create DB instances using CLI during point in time RECOVERY if needed######
###Before uncommenting below lines, add below parameters to the job as DB instance names are needed
###stringParam("HCS_RDS_TARGET_INSTANCE1", "", "HCS RDS  DBinstance Identifier 1 for Target DB")
###stringParam("HCS_RDS_TARGET_INSTANCE2", "", "HCS RDS   DBinstance Identifier 2 for Target DB")

####Start commented out for creating instances using Arch-yaml#####
# Once cluster is restored, instance need to be restored. This will be uncommented after testing or placed in a separate job
# Creating instance 1
#aws rds create-db-instance --db-instance-identifier ${HCS_RDS_TARGET_INSTANCE1}  \
#--db-cluster-identifier ${TARGET_HCS_RDS_CLUSTER_ID} --db-instance-class db.t2.small \
#--engine aurora --region us-east-1

# Creating instance 2
#aws rds create-db-instance --db-instance-identifier ${HCS_RDS_TARGET_INSTANCE2}  \
#--db-cluster-identifier ${TARGET_HCS_RDS_CLUSTER_ID} --db-instance-class db.t2.small \
#--engine aurora --region us-east-1
####End commented out for creating instances using Arch-yaml#####
####End below section can be uncommented to create DB instances using CLI during point in time RECOVERY######
         ''')

     }
 }
