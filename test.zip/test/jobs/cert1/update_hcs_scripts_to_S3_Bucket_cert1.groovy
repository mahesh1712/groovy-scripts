branch = "master"
git_url = "https://github.deere.com/ECommerce/ecommerce-hcs-infra"

freeStyleJob('hcs_57/update-hcs-scripts-to-S3-Bucket-cert1') {
    logRotator(numToKeep = 10,daysToKeep = 10)
    label('cert-slave')
    parameters {
        stringParam("SOURCE_DOR", "customscripts/cloudwatch/", "Script Path")
		stringParam("DESC_DOR", "aws-parts-ecommerce-cert1-hcs/customscripts/cloudwatch/", "Enter S3 bucket path")
		choiceParam('ISDIR', ['yes', 'no'], 'yes - If pushing directory to S3 bucket otherwise select no')

    }
    scm {
	    git {
            remote {
                  url(git_url)
                  credentials('hcs-infra-github-token')
            }
            branch(branch)
        }
    }
    steps {
        shell( '''
#!/bin/bash

echo ${SOURCE_DOR}
echo ${DESC_DOR}

if [ ${ISDIR} == "yes" ]; then
	RECUSRSIVE="--recursive"
else
	RECUSRSIVE=""
fi
aws --region us-east-1 s3 cp ${SOURCE_DOR} s3://${DESC_DOR} ${RECUSRSIVE} --sse AES256
 echo "**Upload Successfully**"

        ''')
    }
}