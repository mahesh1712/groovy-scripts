branch = "master"
git_url = "https://github.deere.com/ECommerce/ecommerce-hcs-infra"

freeStyleJob('hcs_57/create-update-hcs-kms-stack-cert1') {
    logRotator(numToKeep = 100)
    parameters {
        stringParam("ACCOUNT_NUMBER", "122749220977", "AWS Account Number")
        stringParam("ACCOUNT_ALIAS", "aws-parts-ecommerce")
        stringParam("ENVIRONMENT", "cert1")
        stringParam("ROLE_NAME", "jenkins/appslave-jenkins-partsecommerceapps")
        choiceParam("OPERATIONS", ["dry_run","deploy","delete"])
        choiceParam("RE_CREATE", ["false","true"])
    }
    scm {
	    git {
            remote {
                  url(git_url)
                  credentials('hcs-infra-github-token')
            }
            branch(branch)
        }
    }
    steps {
        shell( '''
#!/bin/bash
ARCH_FILE=aws-cloudformation/arch-yamls/arch-hcs-kms.j2
VAR_FILE=aws-cloudformation/config/$ACCOUNT_ALIAS-$ENVIRONMENT/hcs-kms.yml
STACK_NAME=hcs-kms-stack-cert1
CONFIG_FILE=aws-cloudformation/stack-params/$ACCOUNT_ALIAS-$ENVIRONMENT.config
TEMPLATE_URL=$ACCOUNT_ALIAS-cert-system/templates/hcs-kms-stack-cert1.json
ROLE_NAME=$ROLE_NAME


if [ "$RE_CREATE" = false ]
then
   FORCE_DELETE=""
else
   FORCE_DELETE=--force_delete
fi

python --version
python -m cloud_common.aws_stack_operation \\
--region us-east-1 \\
--role_name $ROLE_NAME \\
--account_number $ACCOUNT_NUMBER \\
--operation $OPERATIONS \\
--arch $ARCH_FILE \\
--var $VAR_FILE \\
--stack_name $STACK_NAME \\
--config_file $CONFIG_FILE \\
--template_url $TEMPLATE_URL \\
--log DEBUG $FORCE_DELETE $USE_EXISTING
        ''')
    }
}
