freeStyleJob('hcs_57/create-hcs-rds-manual-snapshot-cert1') {
    logRotator(numToKeep = 100)
    label('cert-slave')
    parameters {
        stringParam("HCS_RDS_CLUSTER_ID", "hcs-rds-stack-cert1-hcsrdscert1rdscluster-lwq2p7ty0kmf", "HCS RDS Cluster Identifier for Source DB")
        stringParam("ACCOUNT_NUMBER", "122749220977", "AWS Account Number")
        stringParam("ACCOUNT_ALIAS", "aws-parts-ecommerce")
        stringParam("ENVIRONMENT", "cert1")
        stringParam("ROLE_NAME", "jenkins/appslave-jenkins-partsecommerceapps")
     }
    triggers {
        cron('0 2 * * *')
    }
    steps {
        //Please keep indentation as shown below to avoid issues in the script.
        shell('''#!/bin/bash
timestamp=$(date +"%Y-%m-%d-%H-%M-%S")
HCS_RDS_SNAPSHOT_NAME=${HCS_RDS_CLUSTER_ID}-manual-snapshot-$timestamp
echo $HCS_RDS_SNAPSHOT_NAME
aws rds create-db-cluster-snapshot --db-cluster-identifier ${HCS_RDS_CLUSTER_ID} --db-cluster-snapshot-identifier ${HCS_RDS_SNAPSHOT_NAME} --region us-east-1 --tags Key=Name,Value=hcsrdssnapshot Key=component,Value=hybris
        ''')

    }
}
